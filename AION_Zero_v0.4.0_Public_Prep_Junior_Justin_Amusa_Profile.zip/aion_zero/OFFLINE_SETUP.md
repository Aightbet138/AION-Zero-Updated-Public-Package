<!-- SPDX-License-Identifier: Apache-2.0 -->

# Offline setup notes — AION Zero v0.4.0

AION's core runs locally with Python and SQLite. No paid API or subscription is needed for memory, billing/accounting recordkeeping, the legal deadline register, local audit verification, deterministic diagnostics, bill prioritization, and storage reporting.

## Strictly offline core

```powershell
py aion.py doctor
py aion.py search "previous deployment issue"
py aion.py task start "Investigate Python traceback" --objective "Find root cause" --environment "local test machine"
py aion.py finance bills list --status open --currency ZAR
py aion.py audit verify
py aion.py storage report --target-pb 1
```

Default keyword search, finance/accounting reports, the bill optimiser, legal register, audit verification, and heuristic bounded-autopilot planning (without `--model`) do not contact Ollama or the internet. SQLite data is stored in the configured local AION data directory.

## Optional local semantic retrieval and chat model

Ollama is addressed at loopback only (`127.0.0.1:11434`). Install it and download models while internet access is available:

```powershell
ollama pull all-minilm
ollama list
py aion.py embeddings index --model all-minilm
py aion.py embeddings stats
py aion.py search "the application keeps dying" --mode semantic --embedding-model all-minilm
```

For local chat reasoning, install a suitable chat model too and use the model's exact name shown by `ollama list`:

```powershell
py aion.py agent "Diagnose why a Python service is restarting" --model YOUR_LOCAL_CHAT_MODEL --workspace .
```

Semantic indexing/search and local chat reasoning require Ollama to be running and the needed model already downloaded; strict offline operation is possible after setup. Model response quality and speed depend on actual RAM/CPU/GPU. The source bundle contains no model weights.

## Engineering skills, autonomy and approval

There are 19 skill packs included in `skillpacks/`:

```powershell
py aion.py skills list
py aion.py skills show cybersecurity_defense
py aion.py skills seed
py aion.py skills evaluate
```

The planner proposes steps; the bounded autopilot uses a fixed allowlist of local diagnostic tool names. Preview first:

```powershell
py aion.py autopilot "Review Python security and configuration" --workspace . --plan-only
```

To run the bounded diagnostics after reviewing the plan:

```powershell
py aion.py autopilot "Review Python security and configuration" --workspace . --approve
```

For a local model to choose only from the tool allowlist, add `--model YOUR_LOCAL_CHAT_MODEL`. AION parses and validates the action names; it will not execute generated shell commands. For project tests, use `--include-tests --allow-code-execution --approve` only for a workspace you trust: tests run with your OS user permissions and this is not a sandbox.

## Finance, accounting and bill optimization

Set up a sample chart of accounts:

```powershell
py aion.py finance setup
py aion.py finance accounts
py aion.py finance bills add "Cloud Provider" "Monthly hosting invoice" --amount 1200.00 --currency ZAR --due 2026-11-05 --category software-cloud --priority 4 --late-fee 50.00
py aion.py finance bills optimize --cash 2000 --currency ZAR --days 30
py aion.py finance entry add "Accrue hosting invoice" --date 2026-10-24 --currency ZAR --line 5100:debit:1200.00 --line 2000:credit:1200.00
py aion.py finance trial-balance --currency ZAR
py aion.py finance budget set software-cloud --period 2026-10 --limit 1500 --currency ZAR
py aion.py finance budget report --period 2026-10 --currency ZAR
```

Bookkeeping values use two decimal places stored as integer minor units. Each entry needs balanced debit/credit lines. Correct posted transactions with a reversal, not a silent edit. The bill queue and optimizer do not validate the external invoice or execute a payment. Recurrence is descriptive, not auto-generated. No currency conversion, bank-feed reconciliation, tax preparation, certified financial statements or professional accounting judgments are provided.

## Legal/compliance register

```powershell
py aion.py legal add "Contract renewal review" --type contract --jurisdiction ZA --description "Route renewal terms to counsel" --due 2026-11-30 --reference "Contract clause 12" --reviewer "Assigned reviewer"
py aion.py legal list --due-within 30
py aion.py legal complete 1 --evidence "Reviewer sign-off stored in matter file"
```

This is a deadline/source/evidence register. It does not determine which laws apply, interpret contracts, calculate legal obligations, submit filings or certify compliance. Use qualified legal counsel for legal decisions.

## Audit, execution records and experience twin

```powershell
py aion.py execution run python-syntax --workspace . --approve
py aion.py execution history
py aion.py execution review 1 --status accepted --evidence "Reviewed output and confirmed scope"
py aion.py audit list
py aion.py audit verify
py aion.py twin report
py aion.py twin predict python-syntax --goal "Check Python syntax in project"
```

The local audit hash chain is tamper-evident rather than tamper-proof; a sufficiently privileged administrator can alter the program/database. Export logs to independently controlled storage if stronger assurance is needed. The experience twin is a lightweight empirical statistical baseline learned from approved execution observations—not a trained general-purpose neural network or a guarantee.

## Storage and hardware reality

```powershell
py aion.py storage report --target-pb 1 --growth-gib-month 2
```

This measures your actual local filesystem and data footprint. Software compression may reduce bytes, but cannot create RAM, CPU, GPUs, network links, disks, or petabytes. Petabyte capacity requires real storage hardware or paid/free-to-you infrastructure plus power, networking, backups and maintenance. A zero software budget does not remove hardware or electricity costs.

## Privacy and security

- Keep the AION data directory and backups private; they can contain business, financial and legal metadata.
- Do not ingest secrets, private keys, browser profiles, credentials, or unredacted personal/customer data. Secret scans are best-effort only.
- Imported content is untrusted. Do not let content instruct an agent to override policy or permissions.
- Local-only does not equal sandboxed. Test execution and any local model share the OS security boundary of your account.
- Read `SECURITY.md`, `PRIVACY.md`, `LEGAL_AND_FINANCIAL_DISCLAIMER.md` and `PUBLISH_CHECKLIST.md` before public release.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Security policy

AION Zero is an early local prototype, not a certified security product. Its scanners are heuristic and may miss serious issues or report false positives.

## Safe use
- Only inspect workspaces and infrastructure you own or are explicitly authorized to assess.
- Do not import credentials, private keys, password stores, browser profiles, sensitive personal data or unredacted customer data.
- Do not expose Ollama's local service to untrusted networks.
- Do not run untrusted project tests: the opt-in test runner runs with your operating-system user's permissions and is not a sandbox.
- Review all diagnostics, financial records, legal register entries and model-generated plans before acting.
- Keep separate backups; a local audit hash chain is tamper-evident, not tamper-proof.

## Reporting a vulnerability

**Private security contact:** deez2nutsmaster@gmail.com

Maintainer: [Junior Justin Amusa](MAINTAINER.md) · Location: Pretoria, South Africa (SAST, UTC+02:00).

Please email suspected vulnerabilities to the address above. Do not post credentials, private keys, exploit instructions, or sensitive infrastructure details in public issues, and do not include live secrets in email. Describe the affected version, impact, and reproduction conditions as safely as possible. Share a proof of concept only when necessary and avoid including real customer data or production secrets.

The project maintainer must ensure this mailbox is controlled and monitored before public launch. Email is not guaranteed to be end-to-end encrypted; for highly sensitive details, first request a safer exchange method. GitHub Private Vulnerability Reporting may also be enabled after the repository is created. There is no guaranteed response time while this is a volunteer/early-stage project.

Allow maintainers a reasonable opportunity to investigate and prepare a fix before public disclosure.

## Scope limits
AION v0.4.0 does not execute arbitrary model-generated shell commands, automate financial transactions, file legal/tax documents or deploy infrastructure. This is not a guarantee that every component is safe. Review code and dependencies before running in sensitive environments.

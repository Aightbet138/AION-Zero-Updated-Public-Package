<!-- SPDX-License-Identifier: Apache-2.0 -->

# Changelog

## 0.4.0 public-prep packaging (2026-10-24)

## Maintainer profile update (2026-10-24)

- Added `MAINTAINER.md` with the maintainer-provided location, UTC+02:00 timezone, email, GitHub, LinkedIn, ORCID and X links.
- Linked maintainer details from README, SECURITY.md and SUPPORT.md.
- Updated NOTICE attribution and the publication checklist. Only the time zone is recorded; a time-of-day is omitted because it becomes stale.


- Added Apache License 2.0, project NOTICE, and preliminary third-party notices.
- Added contribution guidelines, code of conduct, support guidance, pull request and issue templates.
- Expanded publication checklist with maintainer ownership, security-channel, CI, and platform validation gates.
- Added SPDX license identifiers to first-party source/documentation files.
- Set the project copyright attribution to Junior Justin Amusa in `NOTICE` and README; ownership must still be confirmed before publication.
- Hardened `.gitignore` to exclude runtime state, databases, caches, logs, build artifacts, and virtual environments.

This packaging update does not change the versioned engineering behavior of the v0.4.0 prototype. Maintainer ownership and contact details must still be confirmed before publication.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Changelog

## v0.4.0 — Operations, finance, audit and bounded autonomy

- Added `aion_enterprise.py`, sharing the existing local SQLite database and Python-standard-library-only runtime.
- Added bill capture/list/paid/void states and transparent cash-constrained prioritization recommendations. AION never initiates payments; marking a bill paid is only an internal record.
- Added a default chart of accounts, multi-line balanced double-entry journals, currency-grouped trial balance, P&L report, budget limits/actuals/open-bill commitments, and reversal entries rather than silent edits.
- Added a legal/compliance deadline register with jurisdiction, source reference, reviewer and evidence fields. It tracks work; it does not provide legal conclusions or certify compliance.
- Added an append-only SHA-256 hash-chained audit trail, hash verification, audit-safe execution summaries and explanatory tamper-evidence limits.
- Added approval-gated `execution run` and bounded `autopilot` commands. A local model may propose only allowlisted diagnostic tool names; generated shell commands/code are rejected by design. The test runner still requires explicit code-execution consent.
- Added a local experience twin: transparent Beta-smoothed per-tool outcomes/runtime plus optional context-nearest estimation from prior goal text. It is an initial statistical baseline, not a deep neural model.
- Added actual filesystem/storage footprint reporting and explicit petabyte/capacity caveats.
- Added six guide packs for finance/accounting, bill/cash-flow optimization, legal/compliance registers, bounded autonomy, experience twins and scalable storage/compute; total bundled skill packs: 19.
- Added regression tests for finance double-entry, imbalances, reversal, budgets, bills, legal register, audit tampering, approval gating, bounded autopilot, local-model allowlist validation, twin estimates and storage reporting.
- Updated publication checklist, privacy/security guidance and automated cross-platform CI definition.

## v0.3.0 — Engineering skills, local planning agent and diagnostic tools

- Added 13 engineering skill packs across core engineering, Python, Linux/SRE, networking, defensive cybersecurity, cloud, DevOps/CI/CD, containers/Kubernetes, databases/storage, observability/incident response, Git/release hygiene, IT support and secure configuration/code review.
- Added `skills list|show|seed|evaluate`; the deterministic 14-case offline skill-routing benchmark is coverage-only, not proof of general engineering competence.
- Added `agent` to combine task-relevant skill packs, local memory retrieval and optional read-only workspace metadata with a local Ollama chat model. The planner does not execute tools directly.
- Added allowlisted `tools` diagnostics: inspect-tree, python-syntax, secret-scan, config-scan, git-status and opt-in run-tests.
- Added path/symlink checks, bounded scans and secret-safe scan output.

## v0.2 — Semantic memory and local retrieval

- Added schema v3 with `record_embeddings`, model IDs, source hashes, chunk offsets and float32 vector blobs.
- Added explicitly local Ollama embeddings, chunk-level indexing, lexical/semantic/hybrid search and stale-vector invalidation.
- Added migration from the first starter schema while retaining records.

## v0.1 — Offline memory foundation

- Compressed local records and task journals in SQLite.
- Keyword search, provenance, verification states, revisions and record relationships.
- Bounded, allowlisted text/code ingestion with best-effort secret screening.
- Backup/restore, JSONL export, diagnostics, and standard-library-only core.

## Public-prep contact update

- Added deez2nutsmaster@gmail.com as the maintainer-provided security reporting contact in `SECURITY.md` and `README.md`.
- Clarified that the maintainer must verify mailbox access and monitoring before launch; no mailbox configuration is asserted.

## Maintainer profile links (2026-10-24)

- Confirmed the maintainer profile lists Pretoria, South Africa; SAST (UTC+02:00); the security contact email; GitHub `Aightbet138`; LinkedIn; ORCID; and X `@cloudwithjnr`.
- The local time-of-day supplied during setup is not published because it changes; the stable timezone is documented instead.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Python Engineering
Domain: python
Tags: python, debugging, packaging, typing, pytest, unittest, dependencies, profiling, security

## Triage
- Confirm `python --version`, interpreter path, virtual environment, OS, package manager, and how the program is launched.
- Read the full traceback from the first relevant frame. Find the first frame in project code, not merely the last exception line.
- Reproduce with the smallest input and preserve a failing regression test before fixing the defect.
- Inspect imports, working directory, environment-dependent settings, encodings, file permissions, and dependency versions.

## Implementation quality
- Prefer small functions with explicit inputs and outputs. Separate I/O, domain logic, persistence, and user interface.
- Add type hints to public interfaces and docstrings where behavior is not obvious. Avoid abstractions that do not reduce duplication or risk.
- Handle expected errors narrowly. Do not use bare `except`, silently swallow failures, or expose secret values in exceptions or logs.
- Use `pathlib` for paths, context managers for files/resources, parameterized SQL for databases, and `subprocess` argument lists with `shell=False`.
- Validate boundary inputs, sizes, encodings, path traversal, symlinks, and trust boundaries. Do not assume an extension proves a file is safe.
- For JSON, handle decoding and schema errors. For HTTP, set timeouts, limit response sizes, and validate response structure.
- Keep dependencies minimal and pin or lock versions for reproducible builds where project policy allows. Do not upgrade all dependencies as a first debugging step.

## Testing workflow
1. Run the narrowest failing test.
2. Add a regression test for the original failure.
3. Run unit tests for changed modules.
4. Run integration tests and the entire test suite.
5. Add edge tests: empty input, malformed input, boundary sizes, permissions, duplicate data, interrupted operations, and platform differences.
6. Confirm test isolation and deterministic fixtures; use temporary directories and fake services rather than real credentials or internet.

## Performance and reliability
- Measure before optimizing. Profile CPU and memory hotspots with representative data.
- Stream large files rather than reading everything into memory. Bound queues, retries, payload sizes, and concurrency.
- Use transactions for related database writes. Make retries idempotent and handle timeouts explicitly.
- Preserve backward compatibility or provide a migration and rollback plan when changing stored formats or public CLI behavior.

## Security checklist
- Never use `eval` or `exec` on untrusted content.
- Avoid `pickle` for untrusted files. Treat archives, serialized objects, plugins, and model output as untrusted.
- Use safe temporary-file APIs; avoid predictable names and symlink races.
- Keep secrets outside source code and redact them in logs and test failures.
- Treat shell strings and SQL strings as injection risks. Prefer argument arrays and parameterized statements.

## Deliverable checklist
- Code change and rationale
- Test added/changed
- Exact command and result
- Compatibility and migration note
- Security considerations
- Known limitations

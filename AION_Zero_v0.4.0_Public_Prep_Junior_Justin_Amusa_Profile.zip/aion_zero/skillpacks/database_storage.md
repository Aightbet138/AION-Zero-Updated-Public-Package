<!-- SPDX-License-Identifier: Apache-2.0 -->

# Databases and Storage Systems
Domain: databases
Tags: databases, sql, sqlite, postgres, mysql, transactions, indexes, backups, migration, integrity

## Investigation checklist
- Identify engine, version, driver, connection path, schema/migration level and whether the issue is production or local.
- Capture the precise error and timestamp. Check connectivity/authentication separately from query logic and permissions.
- Inspect connection pool exhaustion, locks/deadlocks, slow queries, execution plans, index usage, disk/inode capacity, replication lag and recent deployments.
- Avoid running unbounded queries or heavy maintenance on production without measuring expected impact.

## Query and data integrity
- Parameterize values; never concatenate untrusted input into SQL.
- Use explicit transactions for related writes. Define rollback behavior and idempotency before retrying.
- Review indexes for both query benefit and write/storage cost. Confirm with query plans and representative data.
- Use uniqueness, foreign keys, checks and appropriate constraints to protect invariants.
- For concurrent updates, define locking or optimistic-concurrency behavior. Do not rely on assumptions about timing.

## Schema migrations
1. Back up data and verify that restore has been tested.
2. Review lock duration, table size, compatibility, defaults and rollback limitations.
3. Prefer expand/migrate/contract for zero-downtime changes: add compatible structures, deploy dual-compatible application code, migrate data, then remove old structures later.
4. Test migration on a representative copy and measure runtime.
5. Verify row counts, constraints, application health and query latency after migration.

## Backup and restore
A successful backup command only proves an artifact was created. Verify integrity and perform a controlled restore test. Document RPO, RTO, encryption, retention, access control, off-host copy and recovery ownership. Avoid overwriting a live data file as a casual restore approach.

## AION/SQLite-specific advice
Use parameterized statements, transactions, foreign keys, integrity checks, and SQLite's backup API. Be aware that WAL mode creates sidecar files; copy a live SQLite database using its backup API rather than copying only the main file. Keep database, backups and JSONL exports private because they may contain full decoded content.

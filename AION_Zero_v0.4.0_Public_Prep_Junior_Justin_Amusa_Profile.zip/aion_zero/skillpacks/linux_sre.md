<!-- SPDX-License-Identifier: Apache-2.0 -->

# Linux and SRE Operations
Domain: linux-sre
Tags: linux, systemd, processes, disk, memory, logs, services, reliability, incident, permissions

## Safe first-pass diagnostics
Start with read-only observations: hostname and OS release, uptime/load, `df -h`, `df -i`, `free -h`, `ps`, `ss -lntup` where permissions allow, service status, recent service logs, and process-specific metrics. Commands and available flags vary by distribution; confirm before relying on output.

For systemd systems, typical read-only checks include `systemctl status SERVICE --no-pager`, `journalctl -u SERVICE --since '30 minutes ago' --no-pager`, and `systemctl cat SERVICE`. Avoid dumping full environment values or credential-bearing configuration.

## Triage map
- **Service won't start:** capture the exact failure, inspect service unit and recent logs, validate configuration, binary path, ownership/mode, dependencies, and port conflicts. Run the application's built-in config check if available.
- **Disk full:** inspect filesystem and inode usage, identify largest directories/files with bounded scans, check logs and caches. Do not delete open files or system data blindly. Prefer documented log rotation or application cleanup after approval.
- **Memory pressure/OOM:** correlate memory, swap, OOM logs, process RSS, workload change, and limits. Do not kill arbitrary processes just to make a dashboard green.
- **High CPU/load:** identify the process and workload, inspect recent deploys and traffic, distinguish CPU saturation from I/O wait, and profile before changing limits.
- **Port unreachable:** check listener, bind address, host firewall, routes, security groups, DNS, TLS, and upstream health. Test each network hop from the relevant vantage point.
- **Permission denied:** inspect effective user/group, ownership, parent directory traversal permissions, ACLs and service sandboxing. Never solve routine permission problems with blanket world-writable modes.

## Change discipline
- Capture pre-change state and config backup.
- Prefer a one-service, scoped, reversible change over broad restarts or rebooting the host.
- Confirm blast radius and maintenance window for production.
- Verify service state, health endpoint, logs, latency/error rate, and dependent services afterward.
- Have a rollback command/plan and a defined stop condition before making the change.

## Reliability habits
- Define SLI/SLO and alert thresholds around user-visible outcomes.
- Reduce noisy alerts and attach a runbook to high-severity alerts.
- Track change correlation without assuming correlation proves cause.
- Test backup restoration, not only backup creation.
- Record distributions/versions and exact evidence so a future operator can reproduce the diagnosis.

## Safety
Only administer systems you own or are explicitly authorized to manage. Do not hide activity, disable logging to avoid detection, or bypass access controls. Avoid exposing process arguments or environment output that may contain secrets.

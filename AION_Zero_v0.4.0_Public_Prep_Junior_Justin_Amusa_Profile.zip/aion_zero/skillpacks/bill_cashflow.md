<!-- SPDX-License-Identifier: Apache-2.0 -->

# Bill Management and Cash-Flow Optimization
Domain: finance
Tags: bills, invoices, due dates, late fees, cash flow, payment prioritization, budget optimization

## Purpose
Maintain an accurate queue of bills and generate transparent payment-priority recommendations. Recommendations never initiate payment or replace business judgment.

## Inputs
Capture vendor, invoice description/reference, amount, currency, due date, category, priority, late-fee/penalty information when known, recurrence, approval state, and source evidence. Avoid storing credentials or unnecessary personal data.

## Prioritization
Consider overdue days, due-date urgency, known late fees, criticality of service, amount, contractual/legal consequences, discounts, available cash, and reserve requirements. Separate factual inputs from assumptions. Never assume an invoice or penalty is valid merely because it was entered.

## Verification
- Deduplicate by vendor invoice/reference and compare amount/currency/date before posting.
- Confirm approval and invoice authenticity outside the AI.
- Keep adequate cash reserves and avoid using a greedy score as a substitute for treasury policy.
- Never auto-pay, contact a bank, or change standing instructions.
- Explain which factors drove each recommendation and what was unknown.

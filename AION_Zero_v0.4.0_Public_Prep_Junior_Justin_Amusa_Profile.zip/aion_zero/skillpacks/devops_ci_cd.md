<!-- SPDX-License-Identifier: Apache-2.0 -->

# DevOps and CI/CD Engineering
Domain: devops
Tags: devops, ci-cd, pipelines, testing, releases, deployment, rollback, infrastructure-as-code, supply-chain

## Pipeline stages
1. Checkout a pinned source revision and validate repository trust boundaries.
2. Install dependencies reproducibly from lockfiles; avoid leaking package credentials in logs.
3. Run formatting/lint, static checks and unit tests; keep failures actionable.
4. Build artifacts once and promote the same immutable artifact through environments.
5. Generate dependency/build provenance and scan dependencies/images according to policy.
6. Use short-lived deployment credentials and least privilege. Separate build and production deployment permissions.
7. Deploy to staging or a small canary, run smoke/health checks, then expand gradually.
8. Observe error rate, latency, saturation, logs and business-level signals. Stop rollout and rollback when defined thresholds fail.

## Debug a failed pipeline
- Identify the first failing stage and exact commit, runner image, dependency lock, environment and secret/config reference (never print the secret).
- Separate infrastructure failure, deterministic source failure, dependency drift, test flakiness and permissions failure.
- Reproduce with the same versions and environment. Compare last known-good commit.
- Avoid retrying deterministic failures repeatedly; retries are for transient failures with bounded attempts and backoff.
- Fix root cause and add a regression check. Don't skip tests, disable TLS, loosen permissions, or make a job privileged just to get green.

## Release and rollback design
- Use immutable versioned artifacts and explicit release identifiers.
- Prefer blue/green, canary or rolling updates based on workload tolerance.
- Define readiness/liveness behavior and graceful shutdown. Ensure schema migrations have a compatible rollout/rollback plan.
- A rollback may require data or schema remediation; reverting a binary alone does not necessarily restore service.
- Confirm post-deploy health and record exact evidence.

## Infrastructure as code
- Review the plan before apply; detect destructive changes and drift.
- Protect state with access controls, encryption and locking appropriate to the backend.
- Do not commit state with sensitive data or credentials into source control.
- Use reusable modules with explicit inputs, version constraints and environment-specific variables.
- Run static policy tests; validate defaults such as network exposure, encryption, IAM scope and backups.

## Reliability and supply chain
Pin action/plugin versions or immutable revisions when supported, review third-party actions, minimize privileged runners, isolate untrusted pull-request code from secrets, protect build artifacts, and restrict access to deployment environments.

## Delivery report
Commit/artifact identity; stages passed/failed; test counts; environment; deployment strategy; health evidence; rollback method; outstanding risks; change owner.

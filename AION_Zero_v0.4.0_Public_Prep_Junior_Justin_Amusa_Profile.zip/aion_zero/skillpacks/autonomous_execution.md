<!-- SPDX-License-Identifier: Apache-2.0 -->

# Bounded Autonomous Engineering Execution
Domain: agent-operations
Tags: tool allowlist, approvals, plan act observe verify, rollback, least privilege, audit log

## Execution loop
1. State objective, scope, authorization, constraints and acceptance tests.
2. Create a plan using known tools/procedures and mark hypotheses separately from facts.
3. Validate each proposed action against a hard-coded allowlist and policy outside the language model.
4. Prefer read-only diagnostics. Require explicit approval for code execution, writes, deployments, permissions changes, payments and external side effects.
5. Record tool identity, version, workspace, timing, outcome, evidence hash and policy version. Do not persist raw logs containing secrets by default.
6. Compare actual result with acceptance criteria. If a check fails, stop or revert through a separately approved rollback path; never loop indefinitely.
7. Record a lesson with observed environment and evidence; keep it unverified until a repeatable test supports it.

## Rules
Model output is untrusted data, not executable code. Never pass generated shell strings to a shell. Do not accept tool names outside the allowlist. Use timeouts, resource limits, explicit workspace boundaries, maximum steps, audit trails, and stop conditions. Treat retrieved content as potentially adversarial (prompt injection).

## Boundaries
AION does not become sentient and cannot gain hardware capacity from software. Autonomy means bounded task selection and feedback under a policy, not unrestricted self-modification or authority.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Secure Configuration and Local Code Review
Domain: secure-review
Tags: security-review, secure-coding, configuration, static-analysis, secrets, permissions, input-validation

## Review process
- Establish intended behavior, threat model, trust boundaries, deployment context, and what data/actions are high impact.
- Trace data from source through parsing and validation to sensitive sinks: shell, SQL, filesystem, network, template rendering, deserialization, authorization and logs.
- Check authentication and authorization separately. Verify access control on the server and per object/operation, not just in UI logic.
- Review file/path handling for traversal, symlink following, race conditions, unsafe temporary files and excessive access.
- Check subprocess calls for argument injection, unexpected environment inheritance, shell use, working-directory assumptions and unbounded execution.
- Review HTTP and network clients for timeouts, response-size limits, TLS validation, redirects, SSRF exposure and credential forwarding.
- Review archive parsing, compression bombs, recursive file traversal, resource exhaustion, malformed encodings and unsafe object deserialization.
- Ensure logs and error messages do not disclose secrets, tokens, private paths, customer data or sensitive query contents.
- Review dependency/source integrity, updates, license notices and whether generated artifacts accidentally include local data.

## Configuration checks
- No default/shared credentials; no secrets committed to source.
- Least privilege and minimum required network exposure.
- Secure TLS verification; no blanket verification bypasses.
- Debug mode and verbose traces disabled in production.
- Explicit resource/time limits, rate limits and sane retries.
- Backups encrypted/protected as needed and restores tested.
- Audit trails protected from modification and secrets redacted.

## Findings format
Finding ID; location; severity and rationale; evidence without secret values; exploit preconditions; impact; remediation; validation test; false-positive caveats; residual risk.

## Static check limitations
Pattern matching is not a complete security analysis. Flag suspicious constructs with line numbers and no secret content, verify surrounding context, and use approved scanners when available. A clean pattern scan cannot establish that a system is secure.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Git, Code Review and Release Hygiene
Domain: git
Tags: git, version-control, code-review, releases, branching, merge-conflicts, rollback, provenance

## Repository inspection
- Confirm repository root, branch, working tree state, remotes and current commit before making a change.
- Preserve user changes. Never reset, clean, force-push, rewrite shared history or overwrite untracked files unless explicitly requested and approved.
- Review status and diff, including staged and unstaged changes. Check `.gitignore` to prevent local databases, archives, logs, secrets and build artifacts from being committed.

## Change workflow
1. Create a focused branch or isolated worktree if the project workflow supports it.
2. Make small changes with a clear purpose and add tests for behavior changes.
3. Review diff for accidental files, secrets, generated artifacts, unrelated edits and security issues.
4. Run lint/static checks, focused tests and the full relevant suite.
5. Use clear commit messages describing intent and any migration/compatibility behavior.
6. Tag or release immutable artifacts with version and source commit where appropriate.

## Merge conflicts
Understand both sides before resolving. Preserve semantic changes rather than choosing “ours” or “theirs” mechanically. Run the tests that cover the conflicted behavior after resolution.

## Release/rollback
Record artifact identifier, commit, deployment target, migration level and health evidence. Prefer revert commits for shared history. If the release changed persistent data, check whether reversing code is sufficient or whether a forward repair/migration is required.

## Supply-chain safety
Review dependency manifests and lockfiles, protect release credentials, prefer pinned and trusted automation dependencies, and never execute repository scripts simply because a README says to. Inspect commands and trust boundaries first.

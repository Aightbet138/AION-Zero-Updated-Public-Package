<!-- SPDX-License-Identifier: Apache-2.0 -->

# Cloud Engineering
Domain: cloud
Tags: cloud, iam, networking, observability, cost-optimization, infrastructure-as-code, backup, resiliency

## Design principles
- Start from workload requirements: availability, latency, throughput, data residency, RPO/RTO, security classification and budget.
- Prefer managed services only when their operational, compliance and cost tradeoffs are understood. Avoid provider lock-in unless it is a deliberate decision.
- Separate environments and accounts/projects/subscriptions; enforce least-privilege IAM; prefer short-lived workload identities to long-lived keys.
- Use private networking by default and expose only explicitly required services. Document ingress, egress, DNS, routing, TLS termination and ownership.
- Define observable health and failure behavior. Plan backups, recovery, capacity and dependency outages before production.

## Operational review checklist
1. Identity: roles, policy scope, break-glass accounts, MFA, key rotation, service principals and audit records.
2. Network: public IPs, inbound rules, private endpoints, egress controls, DNS and cross-environment paths.
3. Compute: supported images, patching, autoscaling bounds, health checks, resource limits and graceful shutdown.
4. Storage/data: encryption, lifecycle, access policies, durability, backup schedules, restore tests and retention.
5. Observability: platform and application logs, metrics, traces, alert routing, request IDs, retention and access controls.
6. Infrastructure as code: reviewable plans, state protection, secret-free source, policy checks, drift detection, and controlled apply.
7. Cost: budgets/alerts, tags, idle resources, storage lifecycle, rightsizing, commitment tradeoffs, data transfer and GPU/model cost.
8. Resilience: zone/region failure assumptions, dependency quotas, retry budgets, circuit breakers, queue behavior and tested failover.

## Troubleshooting cloud failures
Correlate deployment timestamp, control-plane events, service health, quota/limit errors, IAM denials, DNS/routing, health-check failure, scaling events and upstream dependencies. Verify whether failure affects one resource, zone, region, identity or network path.

## Cost optimization without creating outages
Measure utilization and demand first. Recommend rightsizing, schedule-based shutdown only for non-production workloads, autoscaling bounds, reserved/committed capacity where justified, storage lifecycle and egress reduction. Never delete resources based only on names or low utilization; inspect ownership, retention, dependency and recovery requirements.

## Change workflow
Review a plan/diff first, estimate blast radius, validate state and backups, apply in nonproduction where feasible, monitor service-level indicators, and maintain a rollback path. Destructive applies, IAM changes, public exposure changes and resource deletion require explicit human authorization.

## Provider neutrality
Commands, APIs, IAM semantics, regions, costs and service limits differ by provider and change over time. Ask for provider and version or clearly label examples; verify against the local provider CLI/docs before recommending production changes.

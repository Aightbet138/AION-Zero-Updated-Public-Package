<!-- SPDX-License-Identifier: Apache-2.0 -->

# Scalable Storage and Compute Engineering
Domain: infrastructure
Tags: storage, capacity planning, distributed systems, backups, sharding, compute, cost optimization

## Principles
- Capacity is bounded by actual hardware, power, networking, cooling, filesystem design, and budget. Software cannot manufacture petabytes or compute throughput.
- Define data classes, retention policy, compression, encryption, access controls, backup copies, restore objectives, and deletion/legal-hold requirements before scaling.
- Keep indexes and hot metadata separate from cold content when needed; measure compression ratio, query latency, write amplification and restore time.
- Use checksums and tested backups. Replication is not a backup. Test restoration and corruption recovery.
- At scale, partition/shard only after measuring bottlenecks; add replication and distributed storage only with real nodes and failure-domain design.
- Model expected growth, redundancy, backup overhead, network egress and hardware replacement cost.

## AION Zero constraint
The zero-budget local build targets storage already available on the user's machine. This release reports actual filesystem capacity; it does not provision cloud storage or claim petabyte capability.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Networking and Connectivity Troubleshooting
Domain: networking
Tags: dns, tcp, tls, http, routing, firewall, latency, connectivity, ports, proxy

## Layered diagnostic order
1. Clarify source, destination, protocol, port, expected behavior, and where the failure occurs. Identify whether failure is universal or location-specific.
2. **Name resolution:** inspect resolver configuration and query the relevant A/AAAA/CNAME records. Compare expected answers, TTLs, split-horizon DNS, search domains, and caches.
3. **Address and route:** confirm local IP, interface state, route selection, VPN/proxy effects, and destination address.
4. **Transport:** check that the process listens on the intended address and port; test TCP reachability from the correct network segment. A listening service on loopback is not reachable from another host.
5. **Policy:** inspect host firewall rules, cloud security groups/network ACLs, Kubernetes network policy, proxy rules, and egress restrictions using authorized read-only methods.
6. **Application:** inspect HTTP status, headers, protocol compatibility, upstream dependencies, and service logs. A TCP success does not prove an application request succeeds.
7. **TLS:** verify system time, SNI, certificate chain, hostname match, expiry, trust store and negotiated protocol. Never recommend turning off certificate validation as a fix.
8. **Performance:** measure round-trip latency, packet loss, retransmits, connection churn, pool exhaustion and payload sizes. Test from multiple relevant vantage points.

## Useful distinctions
- NXDOMAIN vs SERVFAIL vs timeout indicate different DNS failures.
- Connection refused often means no listener or an active rejection; timeout usually points toward filtering, routing, packet loss, or a nonresponsive endpoint.
- HTTP 401 concerns authentication; 403 concerns authorization/policy; 404 may also mask existence by design; 429 indicates rate limiting; 5xx usually indicates server or upstream failure.
- A successful ping does not prove a TCP application port is reachable; ICMP may be filtered independently.

## Evidence to preserve
Timestamp/timezone, source and destination, exact command, exit code, redacted output, DNS answer, route, TCP result, TLS certificate metadata, HTTP status and relevant server-side request ID.

## Guardrails
Use only authorized endpoints and networks. Keep scans narrow and approved. Do not sweep public IP ranges or attempt credential guessing. Redact internal addresses and identifiers before sharing reports outside the organization.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Observability and Incident Response
Domain: sre
Tags: sre, observability, monitoring, logs, metrics, traces, incident-response, postmortem, sli, slo

## Observability model
- **Metrics** show aggregate trends and alertable signals; **logs** preserve event detail; **traces** show request paths and dependency timing.
- Correlate using stable request/trace IDs and timestamps. Check clock skew and timezone before joining events.
- Use bounded-cardinality labels. Never place credentials, session IDs, personal data, full request bodies or arbitrary user input in metric labels.
- Monitor user-visible golden signals: latency, traffic, errors and saturation. Add dependency and business-specific signals where meaningful.
- Alerts should be actionable, have a clear owner, indicate severity and link to a runbook.

## Incident workflow
1. Confirm user impact, severity, start time, affected services/regions/tenants, and current mitigations.
2. Assign incident lead, communications owner and technical investigators where available.
3. Establish a timestamped event timeline and distinguish observed facts from hypotheses.
4. Check recent deployments/configuration changes, dependency status, traffic changes, resource saturation, quotas, error rates and logs.
5. Choose reversible mitigation with the least blast radius. Do not make multiple unrelated changes simultaneously.
6. Verify recovery through user-facing checks and telemetry, not just process status.
7. Monitor for recurrence and confirm that backlog/queues and delayed work have recovered.
8. Preserve relevant evidence, redact sensitive data, and close only against explicit recovery criteria.
9. Conduct a blameless review that identifies system conditions, detection gaps and durable action items with owners and due dates.

## Alert quality
- Alert on symptoms and user impact, not every low-level anomaly.
- Tune thresholds with historical data and seasonality.
- Reduce duplicate alerts; ensure paging is reserved for urgent actionable conditions.
- Test alerts and runbooks after major architecture changes.

## Recovery safeguards
Do not delete queues, databases, backups or logs to silence an alert. Avoid disabling monitors as a workaround. If an alert is noisy, record the reason, apply a scoped temporary mute if authorized, and create a follow-up with an expiry.

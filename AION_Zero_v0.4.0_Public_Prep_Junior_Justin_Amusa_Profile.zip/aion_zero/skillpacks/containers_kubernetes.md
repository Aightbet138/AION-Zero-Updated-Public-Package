<!-- SPDX-License-Identifier: Apache-2.0 -->

# Containers and Kubernetes
Domain: containers
Tags: docker, containers, kubernetes, images, probes, resources, orchestration, manifests, supply-chain

## Container image hygiene
- Use a maintained minimal base image appropriate for the application; pin versions/digests for reproducibility where practical.
- Use multi-stage builds to keep compilers, package caches and development tools out of runtime images.
- Run as a non-root user, drop unnecessary capabilities, avoid privileged mode, and use a read-only root filesystem when feasible.
- Keep secrets out of Docker build arguments, image layers, environment dumps and build logs. Use runtime secret mechanisms.
- Add .dockerignore rules for repository history, local data, credentials, generated artifacts and test caches.
- Set health checks and CPU/memory constraints, and handle SIGTERM/graceful shutdown.

## Kubernetes diagnostic order
1. Confirm namespace, context, workload, recent events and exact rollout revision. Never assume the current kube-context is the intended cluster.
2. Inspect desired vs available replicas, pod phase, restart count, container state, events and scheduling reasons.
3. Read bounded container logs, including previous-container logs if it restarted. Redact sensitive values.
4. Check image pull/status, service selectors/endpoints, readiness/liveness/startup probes, resource requests/limits, node capacity, taints/tolerations and affinity.
5. Check config/secret references without dumping secret objects, storage mounts, DNS, network policy, ingress and upstream dependencies.
6. Compare the failed rollout with the last known-good deployment and inspect the rendered manifest/diff.
7. Make the narrowest fix and watch rollout, service endpoints, health probes, error rate and latency.

## Common symptoms
- `ImagePullBackOff`: image/tag/registry authorization/network/architecture; do not print registry credentials.
- `CrashLoopBackOff`: inspect termination reason and prior logs; consider app config, permission, missing dependency, startup behavior or resource limits.
- Pending pod: inspect scheduling events, quota, capacity, PVC, node selectors, taints and topology constraints.
- Readiness failure: service may run but should not receive traffic; verify probe path/port and startup time before weakening checks.
- OOMKilled: inspect resource limit, memory trend and workload sizing; raising limits alone may shift the failure to the node.
- Service unreachable: verify service selectors/endpoints, target port, pod readiness, DNS, network policy and ingress path.

## Change discipline
Inspect rendered manifests and diff before applying. Use namespace/context explicitly. Avoid broad cluster-wide changes, wildcard RBAC, privileged pods and deletion of persistent volumes. Require approval for production apply/delete and preserve a rollback revision where possible.

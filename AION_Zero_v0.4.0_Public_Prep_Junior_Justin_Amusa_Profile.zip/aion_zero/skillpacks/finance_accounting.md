<!-- SPDX-License-Identifier: Apache-2.0 -->

# Finance and Accounting
Domain: finance
Tags: double-entry bookkeeping, general ledger, chart of accounts, trial balance, profit and loss, budgeting, reconciliation

## Purpose
This reference supports local bookkeeping workflows. It is not a substitute for an accountant, tax adviser, auditor, or regulated financial professional.

## Core controls
- Use double-entry accounting: total debits must equal total credits for each journal entry and currency.
- Use decimal/integer minor-unit amounts; never use binary floating point for ledger arithmetic.
- Create corrections through reversing entries instead of silently editing posted entries.
- Preserve source references, invoice/bill records, dates, currency, supporting documents, and approval history.
- Reconcile bank statements to ledger entries; imported statement text should be treated as untrusted data and checked for duplicates.
- Separate cash movements from accruals and commitments. A bill being marked paid in an internal tracker does not make an external payment.
- Report budgets, income, expenses, assets and liabilities by period and currency. Do not add different currencies without an explicit exchange-rate source and date.

## Verification checklist
1. Confirm period, accounting basis, legal entity, reporting currency and source documents.
2. Reconcile opening balances and cash/bank statements.
3. Confirm each entry is balanced, supported and classified consistently.
4. Check duplicate invoice/reference IDs and unusual amounts.
5. Produce trial balance and financial reports; investigate differences and negative balances.
6. Keep immutable evidence and record reviewer sign-off.

## Safety
Never invent transactions, tax treatment, rates, approvals or accounting policy. Report uncertainty and ask for a qualified review where required.

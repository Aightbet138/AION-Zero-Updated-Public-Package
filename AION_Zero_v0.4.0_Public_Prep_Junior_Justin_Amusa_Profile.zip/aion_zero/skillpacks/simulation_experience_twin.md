<!-- SPDX-License-Identifier: Apache-2.0 -->

# Simulation and Experience Twin
Domain: simulation
Tags: digital twin, scenario analysis, machine learning, calibration, observations, forecasting

## Purpose
Use an explicit representation of a system and its observed history to compare what-if scenarios. Keep assumptions, baseline measurements, uncertainty, and observed outcomes visible.

## Method
- Capture reproducible system/tool identity, environment versions, operating conditions and task outcomes.
- Separate direct measurements from labels entered by a human and from model estimates.
- Start with transparent statistical baselines (rates, intervals, averages, moving averages) before adding more complex local ML.
- Evaluate on held-out or future observations, report sample size and calibration, and compare against a naive baseline.
- Never treat a small dataset's percentage as a reliable guarantee. Surface lack of data and distribution changes.
- For financial or capacity scenarios, state all inputs; do not combine currencies without explicit rates and dates.

## Safety
Predictions must not automatically authorize deployments, payments, legal filings, security changes or irreversible actions. Human review remains required for high-impact decisions.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# Legal and Compliance Register
Domain: compliance
Tags: legal deadlines, obligations, jurisdiction, contracts, evidence, policy, audit readiness

## Purpose
Track deadlines, sources, responsible reviewers, evidence, status and follow-up actions. A register is an organizational aid, not a legal conclusion.

## Required records
Capture matter/obligation title, jurisdiction, source citation or contract clause, deadline, responsible owner/reviewer, status, supporting evidence and update history. Record the version/date of external requirements when available.

## Workflow
1. Record the source and exact deadline as supplied by an authorized person.
2. Flag overdue and near-due items; do not infer legal applicability from keyword matches.
3. Route legal interpretations, filings, contractual changes, jurisdiction questions and completion sign-off to qualified counsel or the responsible compliance officer.
4. Preserve evidence and make corrections traceable.
5. Mark items complete only with documented reviewer evidence; never claim the register itself certifies compliance.

## Safety
Do not invent laws, legal deadlines, case outcomes or professional advice. If authoritative current legal research is needed, request or retrieve a reliable source and preserve the jurisdiction and effective date.

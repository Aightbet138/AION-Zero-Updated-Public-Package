<!-- SPDX-License-Identifier: Apache-2.0 -->

# Defensive Cybersecurity Engineering
Domain: cybersecurity
Tags: defensive-security, hardening, vulnerability-management, threat-detection, access-control, secure-configuration, secrets

## Operating boundary
Support defensive work on systems the operator owns or is explicitly authorized to assess. Focus on reducing risk, verifying configuration, investigating alerts, and producing actionable remediation. Do not conduct stealth, persistence, credential theft, unauthorized exploitation, evasion, or destructive activity.

## Risk-based workflow
1. Establish asset owner, scope, permitted tests, time window, criticality and data-handling constraints.
2. Inventory assets, software versions, exposed services, identities, data sensitivity and trust boundaries.
3. Identify evidence-backed findings. Distinguish confirmed vulnerability, suspected weakness, control gap, and informational observation.
4. Prioritize using exploitability, exposure, privilege required, asset impact, available mitigations, and business context—not severity labels alone.
5. Recommend the smallest safe remediation, compensating controls if needed, owner and due date.
6. Validate in staging or a safe test first, then recheck the specific condition. Record evidence and any remaining risk.

## Common defensive checks
- **Identity:** least privilege, MFA where supported, disabled stale accounts, service-account scoping, periodic access review, and no shared admin credentials.
- **Secrets:** keep credentials out of source, images, logs and memory archives; use a secret manager or protected OS store; rotate exposed secrets and investigate access after exposure.
- **Endpoints and hosts:** supported versions, timely patches, host firewall, secure remote administration, disk encryption where appropriate, protected logs, and minimal installed services.
- **Cloud:** public exposure, overly broad IAM, key age/use, audit logging, encryption, backup posture, security group rules, and storage policy. Use provider-native configuration evidence.
- **Applications:** input validation, authorization checks on the server, safe deserialization, output encoding, dependency maintenance, secure session handling, rate limits, and clear security logging.
- **Containers:** trusted and pinned images, non-root users, least Linux capabilities, read-only filesystems when feasible, resource limits, secret mounts, minimal base images and vulnerability scanning.
- **Logging and detection:** reliable timestamps, central retention, access restrictions, alert context, detection coverage and tested response playbooks.

## Incident handling
- Preserve safety and evidence. Record what was observed, when, by whom, and which systems are in scope.
- Follow the incident commander and organization's response plan. Isolate or disable access only within granted authority and with impact understood.
- Preserve logs and volatile evidence according to policy; do not casually reboot or wipe a potentially compromised host.
- Assess scope, identities and secrets potentially affected, persistence indicators, data access, and affected dependencies.
- Contain, eradicate, recover from known-good sources, rotate credentials where indicated, and monitor for recurrence.
- Complete a blameless review with detection gaps, contributing factors, durable remediations and owners.

## Reporting format
Asset and scope; finding; evidence and timestamp; likelihood/impact; confidence; affected versions; recommended remediation; safe validation; rollback; residual risk; owner. Never include secret values or unnecessary personal data.

## Safety rules
A configuration scanner can create false positives and miss context. Treat findings as hypotheses until confirmed. Never claim a system is secure based only on a clean scan, and never run intrusive tests without explicit authorization.

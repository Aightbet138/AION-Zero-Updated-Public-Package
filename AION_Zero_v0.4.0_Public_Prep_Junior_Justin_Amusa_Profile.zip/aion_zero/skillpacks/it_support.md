<!-- SPDX-License-Identifier: Apache-2.0 -->

# IT Support and Endpoint Administration
Domain: it-support
Tags: it, troubleshooting, windows, macos, endpoint, permissions, updates, backups, helpdesk

## Intake
Capture the user's goal in their words, device/OS/version, affected user and scope, when it started, exact error, recent changes, business impact, reproduction steps, network/VPN context, and urgency. Do not ask for passwords or one-time codes.

## Low-risk troubleshooting sequence
1. Reproduce and capture the exact error without exposing personal or sensitive data.
2. Check status pages or known incidents where available, then determine whether the fault is device-, account-, network-, application- or service-wide.
3. Start with read-only checks: version, available disk space, process/service health, network state, time/date, configuration and logs.
4. Compare with a known-good device or account only when authorized and privacy is protected.
5. Try the smallest reversible correction first. Preserve user data and make a backup before state-changing repair.
6. Validate the original workflow and adjacent functionality, document the fix and provide a user-readable explanation.

## Windows reminders
Use built-in settings and read-only PowerShell diagnostics where possible. Verify command availability and required privilege. Do not disable Defender, firewall, update controls or execution policies as a blanket fix. Avoid printing full process command lines or environment data that may contain secrets.

## Endpoint safety
- Confirm backups before reinstall, profile reset, disk repair, encryption change or mass deletion.
- Follow organizational patching, endpoint protection, device encryption and least-privilege policies.
- Do not bypass account lockouts or access controls. Use approved identity recovery.
- Remote support must be authorized, visible where policy requires, and logged appropriately.

## Ticket closure
Record impact, cause or best-supported explanation, safe actions taken, validation evidence, data preserved, remaining risk, user confirmation if appropriate, and prevention recommendation.

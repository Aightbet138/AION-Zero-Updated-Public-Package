<!-- SPDX-License-Identifier: Apache-2.0 -->

# Privacy and data handling

## Default data location
AION stores its database and related local state in `data/` beside the application by default, or in the path supplied by `AION_DATA_DIR`. It does not configure a hosted database or hosted AI API. Finance and legal register entries, audit events and execution metadata are stored in the same local database.

## Local model access
When explicitly requested, local AI features send prompt/context data to the Ollama service at `127.0.0.1:11434`. This is a loopback request to the local machine, not a hosted Anthropic/OpenAI API request. The downloaded model software may have its own license and runtime characteristics.

## Sensitive data
The importer uses filename and pattern checks for some common credentials, but these checks are incomplete. Scan findings avoid reproducing matched secret values; that does not make arbitrary source files safe to ingest. Minimize records and avoid storing bank account details, payment credentials, privileged cloud tokens, private keys, or unnecessary personal data.

## Exports and audit logs
JSONL exports contain decompressed record bodies. SQLite backups and logs may contain financial/legal/business metadata. Protect, encrypt and limit retention of backups according to the organization's policy. The application does not currently provide built-in encryption at rest, multi-user permissions, retention automation, or remote deletion management.

# Community Code of Conduct

AION Zero aims to maintain a welcoming, respectful, and safety-conscious community.

## Expected behavior

- Be respectful, constructive, and considerate of different backgrounds and experience levels.
- Critique ideas and code, not people.
- Give actionable feedback and acknowledge uncertainty.
- Respect privacy. Do not post secrets, personal data, customer information, or private system details.
- Follow the project's security disclosure process for vulnerabilities instead of posting exploit details publicly.

## Unacceptable behavior

Harassment, threats, discriminatory language, doxxing, deliberate intimidation, repeated abusive conduct,
posting another person's private information without permission, or encouraging unauthorized access to systems
is not acceptable.

## Maintainer response

Maintainers may edit or remove harmful content, close discussions, or limit participation when necessary to
protect participants and the project. Report conduct concerns through the repository's configured contact
or moderation mechanisms. A monitored contact must be configured by the maintainers before publication.

This code of conduct is a community guideline, not a promise of continuous monitoring or a guarantee of safety.

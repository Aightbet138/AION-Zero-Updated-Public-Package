<!-- SPDX-License-Identifier: Apache-2.0 -->

# Maintainer profile

**Name:** Junior Justin Amusa  
**Location:** Pretoria, South Africa  
**Time zone:** South Africa Standard Time (SAST), UTC+02:00  
**Security contact:** [deez2nutsmaster@gmail.com](mailto:deez2nutsmaster@gmail.com)

## Public profiles

- **GitHub:** https://github.com/Aightbet138
- **LinkedIn:** https://www.linkedin.com/in/junior-justin-amusa-6914563b3
- **ORCID:** https://orcid.org/0009-0006-9060-3164
- **X:** [@cloudwithjnr](https://x.com/cloudwithjnr)

## Security reports

Please follow [`SECURITY.md`](SECURITY.md) when reporting vulnerabilities. Do not post secrets or sensitive infrastructure details in public issues. The maintainer must keep the listed email accessible and monitored; the existence of this document does not itself configure an inbox or enable GitHub private vulnerability reporting.

## Project attribution

The project currently attributes AION Zero's first-party code and documentation to Junior Justin Amusa, subject to confirmation that the maintainer has the rights required to distribute all included material. See [`NOTICE`](NOTICE), [`LICENSE`](LICENSE), and [`PUBLISH_CHECKLIST.md`](PUBLISH_CHECKLIST.md).

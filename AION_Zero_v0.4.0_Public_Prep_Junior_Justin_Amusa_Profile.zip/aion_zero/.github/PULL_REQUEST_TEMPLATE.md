## Summary

<!-- What changes and why? -->

## Validation

- [ ] `python -m py_compile aion.py aion_skills.py aion_tools.py aion_enterprise.py test_aion.py`
- [ ] `python -m unittest -v test_aion.py`
- [ ] No network required by the changed core workflow
- [ ] Documentation updated where needed

## Safety and data handling

- [ ] No secrets, personal data, customer data, or private infrastructure details included
- [ ] Permission boundaries, audit trails, and offline behavior remain intact
- [ ] Third-party code/assets/licenses are documented

## Known limitations or migration notes

<!-- Include relevant details. -->

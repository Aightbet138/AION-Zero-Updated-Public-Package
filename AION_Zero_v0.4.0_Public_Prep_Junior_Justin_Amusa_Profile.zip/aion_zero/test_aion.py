# SPDX-License-Identifier: Apache-2.0
"""AION Zero regression and safety tests. All data is created in temporary directories."""
import gzip
import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

APP = Path(__file__).resolve().parent / "aion.py"


class AionTests(unittest.TestCase):
    def run_cli(self, data_dir, *args, expected=0):
        env = os.environ.copy()
        env["AION_DATA_DIR"] = str(data_dir)
        result = subprocess.run([sys.executable, str(APP), *map(str, args)], capture_output=True,
                                text=True, env=env, timeout=30)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result.stdout + result.stderr

    def test_init_add_search_persistence_and_compression(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            out = self.run_cli(data, "init")
            self.assertIn("Integrity: ok", out)
            body = "Before a deployment, run automated regression tests. " * 120
            out = self.run_cli(data, "add", "Deployment lesson", "--body", body, "--kind", "lesson", "--category", "devops")
            self.assertIn("record #1", out)
            out = self.run_cli(data, "search", "regression deployment")
            self.assertIn("Deployment lesson", out)
            out = self.run_cli(data, "show", "1")
            self.assertIn(body[:100], out)
            out = self.run_cli(data, "stats")
            self.assertIn("Compressed body savings:", out)
            self.assertIn("FTS5 metadata search:", out)

    def test_duplicate_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "add", "Same", "--body", "Unique durable lesson.", "--kind", "knowledge")
            out = self.run_cli(data, "add", "Different title", "--body", "Unique durable lesson.", "--kind", "knowledge")
            self.assertIn("duplicate: record #1", out)
            self.assertIn("Records: 1", self.run_cli(data, "stats"))

    def test_secret_rejected_and_searchable_record_not_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            out = self.run_cli(data, "add", "Bad sample", "--body", "-----BEGIN RSA PRIVATE KEY-----\nsecret",
                               expected=1)
            self.assertIn("NOT saved", out)
            self.assertIn("Records: 0", self.run_cli(data, "stats"))

    def test_verification_requires_evidence_and_correct_transition(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self._load_module_for_data_dir(Path(tmp) / "db")
            import contextlib
            import io
            def run(*args):
                stdout, stderr = io.StringIO(), io.StringIO()
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    status = module.main(list(args))
                return status, stdout.getvalue() + stderr.getvalue()
            status, _ = run("add", "Fix procedure", "--body", "Restart the lab container and run the test.", "--kind", "procedure")
            self.assertEqual(status, 0)
            status, out = run("verify", "1", "--status", "verified", "--evidence", "Looks good.")
            self.assertEqual(status, 1)
            self.assertIn("Only a 'tested' record", out)
            status, _ = run("verify", "1", "--status", "tested", "--evidence", "Unit test passed on Python 3.12.")
            self.assertEqual(status, 0)
            status, _ = run("verify", "1", "--status", "verified", "--evidence", "Integration test passed on the stated lab version.", "--confidence", "0.95")
            self.assertEqual(status, 0)
            status, out = run("show", "1")
            self.assertEqual(status, 0)
            self.assertIn("verification_status: verified", out)
            self.assertIn("0.95", out)
            self.assertIn("Integration test passed", out)

    def test_task_journal_and_lesson_creation(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            out = self.run_cli(data, "task", "start", "Fix container health check", "--objective", "Make local service health check pass", "--environment", "Linux lab", "--versions", "Docker 27", "--category", "devops")
            self.assertIn("Task #1", out)
            self.run_cli(data, "task", "update", "1", "--field", "hypotheses", "--value", "Container listens on a different port")
            self.run_cli(data, "task", "update", "1", "--field", "actions", "--value", "Inspected healthcheck config")
            out = self.run_cli(data, "task", "close", "1", "--outcome", "success", "--validation", "Health check passed in 3 consecutive runs", "--lesson", "Match health-check port to service port", "--solution", "Update the health-check port and retest")
            self.assertIn("lesson created as record #2", out)
            out = self.run_cli(data, "task", "show", "1")
            self.assertIn("Container listens on a different port", out)
            self.assertIn('"outcome": "success"', out)
            out = self.run_cli(data, "related", "1")
            self.assertIn("#2", out)
            self.assertIn("unverified", out)

    def test_feedback_persists_and_is_searchable(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "add", "Python script", "--body", "Use a temporary directory in unit tests.", "--kind", "knowledge")
            out = self.run_cli(data, "feedback", "1", "worked", "--lesson", "Temporary directory test passed.")
            self.assertIn("Feedback stored", out)
            out = self.run_cli(data, "search", "Temporary directory test")
            self.assertIn("Feedback on #1", out)

    def test_ingest_skips_secrets_and_symlinks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "notes"
            root.mkdir()
            (root / "good.md").write_text("Kubernetes readiness probes monitor application health.", encoding="utf-8")
            (root / "bad.txt").write_text("ghp_" + "A" * 35, encoding="utf-8")
            (root / ".env").write_text("nothing useful", encoding="utf-8")
            outside = Path(tmp) / "outside.md"
            outside.write_text("symlink target content", encoding="utf-8")
            try:
                (root / "link.md").symlink_to(outside)
            except (OSError, NotImplementedError):
                pass
            data = Path(tmp) / "db"
            out = self.run_cli(data, "ingest", root, "--max-files", "20", "--max-total-mib", "5")
            self.assertIn("Import summary", out)
            self.assertIn("good.md", out)
            self.assertIn("skipped", out)
            self.assertNotIn("ghp_", self.run_cli(data, "search", "ghp"))
            self.assertIn("readiness probes", self.run_cli(data, "search", "readiness probes"))

    def test_backup_restore_and_jsonl_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "add", "Memory A", "--body", "Backups preserve durable memory.", "--kind", "knowledge")
            backup = Path(tmp) / "backups" / "aion.sqlite3"
            out = self.run_cli(data, "backup", backup)
            self.assertIn("Integrity: ok", out)
            export = Path(tmp) / "memory.jsonl.gz"
            out = self.run_cli(data, "export", export, "--gzip")
            self.assertIn("Exported 1 records", out)
            with gzip.open(export, "rt", encoding="utf-8") as fh:
                obj = json.loads(fh.readline())
            self.assertEqual(obj["title"], "Memory A")
            self.run_cli(data, "add", "Memory B", "--body", "A second local record.", "--kind", "knowledge")
            no_confirm = self.run_cli(data, "restore", backup, expected=1)
            self.assertIn("Rerun with --yes", no_confirm)
            out = self.run_cli(data, "restore", backup, "--yes")
            self.assertIn("Restored and validated", out)
            self.assertIn("Memory A", self.run_cli(data, "search", "durable memory"))
            self.assertNotIn("Memory B", self.run_cli(data, "search", "second local record"))

    def test_path_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original = root / "normal.md"
            original.write_text("safe text", encoding="utf-8")
            link = root / "linked.md"
            try:
                link.symlink_to(original)
            except (OSError, NotImplementedError):
                self.skipTest("Symlink creation unavailable on this platform")
            env = os.environ.copy()
            env["AION_DATA_DIR"] = str(root / "db")
            result = subprocess.run([sys.executable, str(APP), "add", "linked", "--file", str(link)],
                                    capture_output=True, text=True, env=env)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("symbolic link", result.stderr.lower())

    def test_doctor_and_memory_commands_do_not_attempt_network(self):
        # Load a separate module instance pointed at a temporary database and block all socket connections.
        with tempfile.TemporaryDirectory() as tmp:
            old_data_dir = os.environ.get("AION_DATA_DIR")
            os.environ["AION_DATA_DIR"] = str(Path(tmp) / "db")
            try:
                spec = importlib.util.spec_from_file_location("aion_offline_test", APP)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                def forbidden(*_args, **_kwargs):
                    raise AssertionError("Unexpected socket connection in offline core path")
                import contextlib
                import io
                with mock.patch.object(socket.socket, "connect", forbidden), contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(mod.main(["doctor"]), 0)
                    self.assertEqual(mod.main(["add", "Offline", "--body", "Offline core persists this."]), 0)
                    self.assertEqual(mod.main(["search", "persists offline"]), 0)
            finally:
                if old_data_dir is None:
                    os.environ.pop("AION_DATA_DIR", None)
                else:
                    os.environ["AION_DATA_DIR"] = old_data_dir

    def test_migrates_older_starter_database_without_losing_records(self):
        import hashlib
        import sqlite3
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            data.mkdir()
            path = data / "aion.sqlite3"
            body = "Legacy memory must survive the schema migration."
            raw = body.encode("utf-8")
            packed = gzip.compress(raw, mtime=0)
            with sqlite3.connect(path) as conn:
                conn.execute("""CREATE TABLE records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, title TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT 'general', tags TEXT NOT NULL DEFAULT '',
                    source TEXT NOT NULL DEFAULT 'manual', sha256 TEXT NOT NULL, body_gzip BLOB NOT NULL,
                    original_bytes INTEGER NOT NULL, compressed_bytes INTEGER NOT NULL,
                    summary TEXT NOT NULL DEFAULT '', outcome TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
                    UNIQUE(sha256, kind))""")
                conn.execute("INSERT INTO records(kind,title,category,tags,source,sha256,body_gzip,original_bytes,compressed_bytes,summary,outcome,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    ("knowledge", "Legacy note", "python", "migration", "manual", hashlib.sha256(raw).hexdigest(), packed, len(raw), len(packed), "old starter", "", "2026-01-01T00:00:00+00:00"))
            out = self.run_cli(data, "search", "legacy memory migration")
            self.assertIn("Legacy note", out)
            shown = self.run_cli(data, "show", "1")
            self.assertIn("verification_status: unverified", shown)
            self.assertIn(body, shown)
            with sqlite3.connect(path) as conn:
                self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], 3)
                self.assertIsNotNone(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='record_embeddings'").fetchone())

    def test_revision_created_when_task_updated(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "task", "start", "Revision test", "--objective", "Check revisions")
            self.run_cli(data, "task", "update", "1", "--field", "actions", "--value", "First attempted action")
            # Verify the prior body was preserved in the revision store.
            import sqlite3
            with sqlite3.connect(data / "aion.sqlite3") as conn:
                count = conn.execute("SELECT COUNT(*) FROM record_revisions WHERE record_id=1").fetchone()[0]
            self.assertGreaterEqual(count, 1)
            history = self.run_cli(data, "history", "1")
            self.assertIn("Revision 1", history)

    def test_structured_procedure_starts_unverified(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            out = self.run_cli(data, "procedure", "add", "Restart local service", "--prerequisites", "Lab VM accessible", "--steps", "Restart service; inspect status", "--expected", "Service returns healthy", "--risks", "Brief outage", "--rollback", "Restore prior config", "--context", "Docker test lab")
            self.assertIn("status=unverified", out)
            shown = self.run_cli(data, "show", "1")
            self.assertIn('"prerequisites": "Lab VM accessible"', shown)
            self.assertIn("verification_status: unverified", shown)

    def test_verification_evidence_rejects_secrets(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "add", "Procedure", "--body", "Use a safe procedure.", "--kind", "procedure")
            out = self.run_cli(data, "verify", "1", "--status", "tested", "--evidence", "ghp_" + "B" * 35, expected=1)
            self.assertIn("Possible credential detected", out)
            shown = self.run_cli(data, "show", "1")
            self.assertIn("verification_status: unverified", shown)

    def _load_module_for_data_dir(self, data_dir):
        old_data_dir = os.environ.get("AION_DATA_DIR")
        os.environ["AION_DATA_DIR"] = str(data_dir)
        try:
            name = f"aion_semantic_test_{id(data_dir)}"
            spec = importlib.util.spec_from_file_location(name, APP)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
        finally:
            if old_data_dir is None:
                os.environ.pop("AION_DATA_DIR", None)
            else:
                os.environ["AION_DATA_DIR"] = old_data_dir

    @staticmethod
    def fake_semantic_embedding(text):
        """Tiny deterministic fake: unrelated wording maps to the same test concept vector."""
        lowered = text.casefold()
        concepts = [
            {"kubernetes", "container", "pod", "liveness", "readiness", "probe", "health", "service", "workload", "orchestration", "crashing", "crash", "terminates", "restarting", "repeatedly", "restart", "docker"},
            {"python", "recursion", "function", "script", "traceback", "exception", "code"},
            {"firewall", "credential", "vulnerability", "security", "password", "attack"},
        ]
        vector = [1.0 if any(word in lowered for word in group) else 0.0 for group in concepts]
        if not any(vector):
            vector = [0.0, 0.0, 1.0]
        norm = sum(value * value for value in vector) ** 0.5
        return tuple(value / norm for value in vector)

    def test_semantic_index_and_search_find_related_wording(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self._load_module_for_data_dir(Path(tmp) / "db")
            module.add_record("knowledge", "Kubernetes health probes", "A liveness probe restarts a container when its health check fails.", category="devops")
            module.add_record("knowledge", "Python recursion exception", "A recursive function can trigger a traceback when the base case is missing.", category="python")
            module.add_record("knowledge", "Firewall review", "Review firewall rules and credentials for security vulnerabilities.", category="cybersecurity")

            def fake_embed(texts, model=module.DEFAULT_EMBEDDING_MODEL):
                return [self.fake_semantic_embedding(text) for text in texts]

            with mock.patch.object(module, "call_ollama_embeddings", side_effect=fake_embed):
                result = module.index_record_embeddings("test-local-embed", batch_size=2)
                self.assertEqual(result["indexed_records"], 3)
                hits = module.find_semantic_records("Why does an orchestrated workload repeatedly terminate?", model="test-local-embed")
                self.assertEqual(hits[0]["title"], "Kubernetes health probes")
                self.assertIn("liveness probe", hits[0]["body"])
                hybrid = module.retrieve_records("Why does an orchestrated workload repeatedly terminate?", mode="hybrid", embedding_model="test-local-embed")
                self.assertEqual(hybrid[0]["title"], "Kubernetes health probes")
                stats = module.index_record_embeddings("test-local-embed", batch_size=2)
                self.assertEqual(stats["indexed_records"], 0)
                self.assertEqual(stats["unchanged_records"], 3)

    def test_semantic_index_invalidated_when_body_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self._load_module_for_data_dir(Path(tmp) / "db")
            rid, _ = module.add_record("knowledge", "Local procedure", "Original procedure details.", category="devops")
            def fake_embed(texts, model=module.DEFAULT_EMBEDDING_MODEL):
                return [self.fake_semantic_embedding(text) for text in texts]
            with mock.patch.object(module, "call_ollama_embeddings", side_effect=fake_embed):
                module.index_record_embeddings("test-local-embed")
                conn = module.connect()
                try:
                    module._update_record_body(conn, rid, "Revised procedure details with more context.")
                    conn.commit()
                    remaining = conn.execute("SELECT COUNT(*) FROM record_embeddings WHERE record_id=?", (rid,)).fetchone()[0]
                finally:
                    conn.close()
                self.assertEqual(remaining, 0)
                with self.assertRaisesRegex(ValueError, "No semantic vectors are indexed"):
                    module.find_semantic_records("procedure steps", model="test-local-embed")

    def test_semantic_embedding_api_is_loopback_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self._load_module_for_data_dir(Path(tmp) / "db")
            class FakeResponse:
                def __enter__(self):
                    return self
                def __exit__(self, *_args):
                    return False
                def read(self):
                    return json.dumps({"embeddings": [[3.0, 4.0]]}).encode("utf-8")
            def fake_urlopen(request, timeout=0):
                self.assertEqual(request.full_url, "http://127.0.0.1:11434/api/embed")
                self.assertGreater(timeout, 0)
                return FakeResponse()
            with mock.patch.object(module.urllib.request, "urlopen", side_effect=fake_urlopen):
                vectors = module.call_ollama_embeddings(["test query"], "test-local-embed")
            self.assertAlmostEqual(vectors[0][0], 0.6, places=5)
            self.assertAlmostEqual(vectors[0][1], 0.8, places=5)

    def test_semantic_chunk_windows_cover_large_document_with_limit(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self._load_module_for_data_dir(Path(tmp) / "db")
            body = "x" * 2_000_000
            windows = module.make_embedding_chunks(body, chunk_chars=850, overlap_chars=120, max_chunks=128)
            self.assertLessEqual(len(windows), 128)
            self.assertEqual(windows[0][0], 0)
            self.assertEqual(windows[-1][1], len(body))

    def test_bundled_skillpacks_are_available_and_domain_routed(self):
        sys.path.insert(0, str(APP.parent))
        try:
            import aion_skills
            packs = aion_skills.load_skillpacks()
            self.assertGreaterEqual(len(packs), 10)
            names = {p["slug"] for p in packs}
            self.assertIn("python_engineering", names)
            self.assertIn("cybersecurity_defense", names)
            selected = aion_skills.select_skillpacks("Python traceback failing unittest", limit=4)
            self.assertEqual(selected[0]["slug"], "core_engineering")
            self.assertIn("python_engineering", {p["slug"] for p in selected})
            selected_sec = aion_skills.select_skillpacks("defensive cybersecurity cloud IAM vulnerability", limit=4)
            self.assertIn("cybersecurity_defense", {p["slug"] for p in selected_sec})
        finally:
            try:
                sys.path.remove(str(APP.parent))
            except ValueError:
                pass

    def test_skills_seeded_into_memory_and_searchable(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            out = self.run_cli(data, "skills", "seed")
            self.assertIn("Skill seeding complete", out)
            stats = self.run_cli(data, "stats")
            self.assertIn("Records: 19", stats)
            found = self.run_cli(data, "search", "Python traceback unittest dependency")
            self.assertIn("Python Engineering", found)
            self.assertIn("unverified", found)

    def test_tools_python_syntax_finds_errors_without_running_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "project"
            root.mkdir()
            (root / "good.py").write_text("def ok():\n    return 1\n", encoding="utf-8")
            (root / "bad.py").write_text("def broken(:\n    pass\n", encoding="utf-8")
            out = self.run_cli(Path(tmp) / "db", "tools", "run", "python-syntax", "--workspace", root)
            report = json.loads(out)
            self.assertEqual(report["checked"], 1)
            self.assertFalse(report["ok"])
            self.assertEqual(report["errors"][0]["path"], "bad.py")

    def test_secret_scan_does_not_return_possible_secret_value(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "project"
            root.mkdir()
            secret = "AKIA1234567890123456"
            (root / "settings.py").write_text(f'AWS_ID = "{secret}"\n', encoding="utf-8")
            out = self.run_cli(Path(tmp) / "db", "tools", "run", "secret-scan", "--workspace", root)
            self.assertIn("possible-secret", out)
            self.assertNotIn(secret, out)

    def test_config_scan_reports_rule_without_echoing_source_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "project"
            root.mkdir()
            (root / "deployment.yaml").write_text("securityContext:\n  privileged: true\n", encoding="utf-8")
            out = self.run_cli(Path(tmp) / "db", "tools", "run", "config-scan", "--workspace", root)
            report = json.loads(out)
            self.assertTrue(any(row["rule"] == "SEC001" for row in report["findings"]))

    def test_test_runner_requires_explicit_code_execution_opt_in(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "project"
            root.mkdir()
            out = self.run_cli(Path(tmp) / "db", "tools", "run", "run-tests", "--workspace", root, expected=1)
            self.assertIn("Re-run with --allow-code-execution", out)

    def test_tools_reject_workspace_symlink(self):
        if not hasattr(os, "symlink"):
            self.skipTest("symlinks unsupported")
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "root"
            root.mkdir()
            link = Path(tmp) / "link"
            try:
                link.symlink_to(root, target_is_directory=True)
            except (OSError, NotImplementedError):
                self.skipTest("symlink creation not permitted")
            out = self.run_cli(Path(tmp) / "db", "tools", "run", "inspect-tree", "--workspace", link, expected=1)
            self.assertIn("symlink", out.casefold())

    def test_local_agent_chat_api_is_loopback_only_and_prompt_disables_execution(self):
        sys.path.insert(0, str(APP.parent))
        try:
            import aion_skills
            class FakeResponse:
                def __enter__(self):
                    return self
                def __exit__(self, *_args):
                    return False
                def read(self):
                    return json.dumps({"message": {"content": "Plan only; no actions executed."}}).encode("utf-8")
            def fake_urlopen(request, timeout=0):
                self.assertEqual(request.full_url, "http://127.0.0.1:11434/api/chat")
                self.assertGreater(timeout, 0)
                payload = json.loads(request.data.decode("utf-8"))
                self.assertIn("do not execute", payload["messages"][0]["content"].casefold())
                return FakeResponse()
            with mock.patch.object(aion_skills.urllib.request, "urlopen", side_effect=fake_urlopen):
                answer = aion_skills.call_local_agent("Diagnose failed tests", "skill context", "test-chat-model")
            self.assertIn("Plan only", answer)
        finally:
            try:
                sys.path.remove(str(APP.parent))
            except ValueError:
                pass

    def test_version_and_new_command_help(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = self.run_cli(Path(tmp) / "db", "--version")
            self.assertIn("AION Zero 0.4.0", out)
            out = self.run_cli(Path(tmp) / "db", "skills", "list")
            self.assertIn("Python Engineering", out)
            out = self.run_cli(Path(tmp) / "db", "tools", "list")
            self.assertIn("run-tests", out)
            self.assertIn("read-only", out)


    def test_skill_routing_benchmark_runs_offline(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = self.run_cli(Path(tmp) / "db", "skills", "evaluate")
            self.assertIn("14/14 (100.0%)", out)
            self.assertIn("not LLM correctness", out)


    def test_agent_plan_is_recorded_as_unverified_task_without_execution(self):
        import contextlib
        import importlib
        import io
        from types import SimpleNamespace
        old_data = os.environ.get("AION_DATA_DIR")
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["AION_DATA_DIR"] = str(Path(tmp) / "db")
            sys.path.insert(0, str(APP.parent))
            try:
                module = importlib.import_module("aion")
                module.DATA_DIR = Path(os.environ["AION_DATA_DIR"]).expanduser().absolute()
                module.DB_PATH = module.DATA_DIR / "aion.sqlite3"
                import aion_skills
                args = SimpleNamespace(goal="Diagnose local Python test failure", skills=3, limit=5,
                    category=None, mode="lexical", embedding_model=module.DEFAULT_EMBEDDING_MODEL,
                    workspace=None, model="fake-local-model", no_save=False)
                output = io.StringIO()
                with mock.patch.object(aion_skills, "call_local_agent", return_value="Plan only. No actions executed."), \
                     contextlib.redirect_stdout(output):
                    aion_skills.cmd_agent(args)
                self.assertIn("Plan journal: task #1", output.getvalue())
                record = module.fetch_record(1)
                self.assertEqual(record["kind"], "task")
                self.assertEqual(record["verification_status"], "unverified")
                self.assertEqual(record["outcome"], "planned-not-executed")
                task = module._load_task_body(record)
                self.assertEqual(task["outcome"], "planned-not-executed")
                self.assertIn("No actions executed", task["actions"][0]["plan"])
            finally:
                try:
                    sys.path.remove(str(APP.parent))
                except ValueError:
                    pass
                if old_data is None:
                    os.environ.pop("AION_DATA_DIR", None)
                else:
                    os.environ["AION_DATA_DIR"] = old_data


class AionEnterpriseTests(unittest.TestCase):
    """Additional offline regression tests for finance, legal, audit, execution and twin."""

    def run_cli(self, data_dir, *args, expected=0):
        env = os.environ.copy()
        env["AION_DATA_DIR"] = str(data_dir)
        result = subprocess.run([sys.executable, str(APP), *map(str, args)], capture_output=True,
                                text=True, env=env, timeout=30)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result.stdout + result.stderr

    def test_bills_priority_and_paid_record_does_not_claim_external_payment(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            out = self.run_cli(data, "finance", "bills", "add", "Power Utility", "Electricity", "--amount", "200.00", "--currency", "ZAR", "--due", "2026-10-24", "--priority", "5", "--late-fee", "25.00")
            self.assertIn("No payment was initiated", out)
            self.run_cli(data, "finance", "bills", "add", "Software Inc", "Subscription", "--amount", "49.99", "--currency", "ZAR", "--due", "2026-10-25", "--priority", "2")
            out = self.run_cli(data, "finance", "bills", "optimize", "--cash", "250.00", "--currency", "ZAR", "--days", "10", "--as-of", "2026-10-24")
            self.assertIn("PRIORITIZE", out)
            self.assertIn("Power Utility", out)
            self.assertIn("heuristic decision-support", out)
            out = self.run_cli(data, "finance", "bills", "pay", "1", "--date", "2026-10-24", "--reference", "Bank statement ref 123")
            self.assertIn("did not send money", out)
            self.assertIn("[paid", self.run_cli(data, "finance", "bills", "list", "--status", "paid"))

    def test_double_entry_budget_and_pnl(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "finance", "setup")
            self.run_cli(data, "finance", "entry", "add", "Owner funding", "--date", "2026-10-01", "--currency", "ZAR",
                         "--line", "1000:debit:1000.00", "--line", "3000:credit:1000.00")
            self.run_cli(data, "finance", "entry", "add", "Cloud bill", "--date", "2026-10-10", "--currency", "ZAR",
                         "--line", "5100:debit:120.00", "--line", "1000:credit:120.00")
            self.run_cli(data, "finance", "entry", "add", "Product sale", "--date", "2026-10-12", "--currency", "ZAR",
                         "--line", "1000:debit:500.00", "--line", "4000:credit:500.00")
            out = self.run_cli(data, "finance", "trial-balance", "--currency", "ZAR")
            self.assertIn("BALANCED", out)
            out = self.run_cli(data, "finance", "pnl", "--start", "2026-10-01", "--end", "2026-10-31", "--currency", "ZAR")
            self.assertIn("net=ZAR 380.00", out)
            out = self.run_cli(data, "finance", "budget", "set", "software-cloud", "--period", "2026-10", "--limit", "100.00", "--currency", "ZAR")
            self.assertIn("Budget set", out)
            out = self.run_cli(data, "finance", "budget", "report", "--period", "2026-10", "--currency", "ZAR")
            self.assertIn("OVER BUDGET", out)
            out = self.run_cli(data, "finance", "entry", "add", "Imbalanced", "--date", "2026-10-15", "--line", "5100:debit:100", "--line", "1000:credit:50", expected=1)
            self.assertIn("Double-entry imbalance", out)

    def test_journal_reversal_preserves_a_balanced_trace(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "finance", "setup")
            self.run_cli(data, "finance", "entry", "add", "Funding", "--date", "2026-10-01", "--reference", "seed-1", "--line", "1000:debit:500", "--line", "3000:credit:500")
            out = self.run_cli(data, "finance", "entry", "reverse", "1", "--date", "2026-10-02", "--reason", "Correct duplicate")
            self.assertIn("reversed by entry #2", out)
            out = self.run_cli(data, "finance", "trial-balance", "--currency", "ZAR")
            self.assertIn("BALANCED", out)
            self.assertIn("TOTAL ZAR: debit ZAR 0.00 | credit ZAR 0.00 | BALANCED", out)

    def test_hash_chained_audit_log_and_tamper_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            self.run_cli(data, "finance", "setup")
            out = self.run_cli(data, "audit", "verify")
            self.assertIn("AUDIT OK", out)
            # Simulate offline tampering by bypassing the append-only trigger in an adversarial DB edit.
            import sqlite3
            db = data / "aion.sqlite3"
            with sqlite3.connect(db) as conn:
                conn.execute("DROP TRIGGER audit_events_no_update")
                conn.execute("UPDATE audit_events SET payload_json='{}' WHERE id=1")
                conn.commit()
            out = self.run_cli(data, "audit", "verify")
            self.assertIn("AUDIT FAIL", out)

    def test_legal_register_is_a_deadline_tracker_not_a_legal_conclusion(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"
            out = self.run_cli(data, "legal", "add", "Contract renewal", "--type", "contract", "--jurisdiction", "ZA", "--description", "Ask counsel to review renewal terms", "--due", "2026-11-30", "--reference", "Contract clause 12", "--reviewer", "External counsel")
            self.assertIn("not a legal conclusion", out)
            out = self.run_cli(data, "legal", "list")
            self.assertIn("Contract renewal", out)
            out = self.run_cli(data, "legal", "complete", "1", "--evidence", "Counsel review recorded in matter file")
            self.assertIn("does not certify legal compliance", out)

    def test_execution_requires_approval_and_records_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"; ws = Path(tmp) / "workspace"; ws.mkdir(); (ws / "sample.py").write_text("x = 1\n", encoding="utf-8")
            out = self.run_cli(data, "execution", "run", "python-syntax", "--workspace", ws, expected=1)
            self.assertIn("--approve", out)
            out = self.run_cli(data, "execution", "run", "python-syntax", "--workspace", ws, "--approve", "--objective", "Check syntax")
            self.assertIn("outcome=passed", out)
            hist = self.run_cli(data, "execution", "history")
            self.assertIn("python-syntax", hist)
            self.assertIn("unreviewed", hist)
            out = self.run_cli(data, "execution", "review", "1", "--status", "accepted", "--evidence", "Reviewed clean parser result")
            self.assertIn("does not certify", out)
            self.assertIn("AUDIT OK", self.run_cli(data, "audit", "verify"))

    def test_autopilot_plan_only_and_approved_bounded_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"; ws = Path(tmp) / "workspace"; ws.mkdir(); (ws / "sample.py").write_text("x = 1\n", encoding="utf-8")
            out = self.run_cli(data, "autopilot", "Review Python security and configuration", "--workspace", ws, "--plan-only")
            self.assertIn("Plan only; no tools ran", out)
            self.assertIn("secret-scan", out)
            self.assertIn("No execution records", self.run_cli(data, "execution", "history"))
            out = self.run_cli(data, "autopilot", "Review Python security and configuration", "--workspace", ws, "--approve", "--max-steps", "4")
            self.assertIn("Autopilot cycle complete", out)
            hist = self.run_cli(data, "execution", "history")
            self.assertIn("secret-scan", hist)

    def test_experience_twin_learns_from_run_observations(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "db"; ws = Path(tmp) / "workspace"; ws.mkdir(); (ws / "sample.py").write_text("x = 1\n", encoding="utf-8")
            self.run_cli(data, "execution", "run", "python-syntax", "--workspace", ws, "--approve", "--objective", "Check Python syntax in a project")
            out = self.run_cli(data, "twin", "predict", "python-syntax", "--goal", "Check Python syntax in project")
            self.assertIn("Historical observations: 1", out)
            self.assertIn("66.7%", out)  # one success under Beta(1,1): (1+1)/(1+2)
            self.assertIn("Context-matched estimate", out)
            out = self.run_cli(data, "twin", "report")
            self.assertIn("transparent Beta(1,1)", out)

    def test_local_autopilot_plan_is_validated_against_allowlist(self):
        import contextlib
        import importlib
        old_data = os.environ.get("AION_DATA_DIR")
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["AION_DATA_DIR"] = str(Path(tmp) / "db")
            sys.path.insert(0, str(APP.parent))
            try:
                aion = importlib.import_module("aion")
                aion.DATA_DIR = Path(os.environ["AION_DATA_DIR"]).absolute()
                aion.DB_PATH = aion.DATA_DIR / "aion.sqlite3"
                import aion_enterprise
                class FakeResponse:
                    def __enter__(self): return self
                    def __exit__(self, *_args): return False
                    def read(self):
                        return json.dumps({"message": {"content": json.dumps({"actions": [
                            {"tool": "python-syntax", "rationale": "Check parsers"},
                            {"tool": "rm -rf", "rationale": "Unsafe arbitrary command"},
                            {"tool": "run-tests", "rationale": "Not user-authorized in this test"}
                        ]})}}).encode("utf-8")
                with mock.patch.object(aion_enterprise.urllib.request, "urlopen", return_value=FakeResponse()):
                    plan = aion_enterprise._local_action_plan("Check Python security", "fake-local-model", tmp, False, 5)
                self.assertEqual([item[0] for item in plan], ["python-syntax"])
            finally:
                try: sys.path.remove(str(APP.parent))
                except ValueError: pass
                if old_data is None: os.environ.pop("AION_DATA_DIR", None)
                else: os.environ["AION_DATA_DIR"] = old_data

    def test_storage_capacity_is_grounded_in_real_filesystem(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = self.run_cli(Path(tmp) / "db", "storage", "report", "--target-pb", "1")
            self.assertIn("backing filesystem", out.casefold())
            self.assertIn("cannot create storage/compute capacity", out)
            out = self.run_cli(Path(tmp) / "db", "storage", "report", "--target-pb", "-1", expected=1)
            self.assertIn("positive finite number", out)


if __name__ == "__main__":
    unittest.main(verbosity=2)

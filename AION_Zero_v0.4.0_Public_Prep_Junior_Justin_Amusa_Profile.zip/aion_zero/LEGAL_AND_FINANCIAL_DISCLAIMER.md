<!-- SPDX-License-Identifier: Apache-2.0 -->

# Legal, financial and accounting limitations

AION Zero's bill tracker, cash-flow prioritization heuristic, chart of accounts, journals, trial balance, P&L and budget reporting are software utilities for organizing user-supplied data. They are not legal, tax, investment, treasury, audit or regulated accounting advice, and they are not certified financial statements.

The bill prioritizer is heuristic decision support. It does not validate invoice authenticity, evaluate all contractual obligations, guarantee that a payment should be delayed, preserve liquidity, contact a bank, or initiate a payment. A bill marked “paid” is only an internal status record.

The legal/compliance register tracks user-supplied jurisdiction, dates, source references, reviewer assignments and evidence. It does not interpret legislation, determine legal applicability, calculate statutory deadlines, interpret contracts, file documents, or certify compliance.

Users are responsible for checking source documents and dates, reconciling records, selecting the relevant accounting policies/currency, protecting confidential data, and obtaining qualified professional review before relying on financial/legal conclusions. The developers make no warranty that the software meets a jurisdiction's accounting, tax, financial-services, records-retention or legal-practice requirements.

# SPDX-License-Identifier: Apache-2.0
"""Scoped, mostly read-only engineering tools for AION Zero.

Tools never invoke a shell. Test execution is deliberately opt-in because test code is code.
These helpers are diagnostics, not a security sandbox, and should only be pointed at
workspaces the operator is authorized to inspect.
"""
from __future__ import annotations

import ast
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any

from aion import ALLOWED_SUFFIXES, DEFAULT_FILE_BYTES, IGNORED_DIRS, SECRET_PATTERNS, _has_symlink_component

MAX_SCAN_FILES = 5000
CONFIG_RULES: list[tuple[str, re.Pattern[str], str]] = [
    ("SEC001", re.compile(r"(?i)\b--privileged\b|\bprivileged\s*:\s*true"), "Privileged container setting"),
    ("SEC002", re.compile(r"(?i)\ballowPrivilegeEscalation\s*:\s*true"), "Privilege escalation allowed"),
    ("SEC003", re.compile(r"(?<![\w.])0\.0\.0\.0/0(?![\w.])"), "Potentially broad network ingress/egress range"),
    ("SEC004", re.compile(r"(?i)\bchmod\s+(?:-R\s+)?777\b"), "World-writable permission setting"),
    ("SEC005", re.compile(r"(?i)\b(?:verify|tls_verify|ssl_verify)\s*=\s*false\b|\bCERT_NONE\b|\bSkipCertificateValidation\b"), "TLS certificate verification may be disabled"),
    ("SEC006", re.compile(r"(?i)\brunAsUser\s*:\s*0\b|\bUSER\s+root\b"), "Container may run as root"),
    ("SEC007", re.compile(r"(?i)\bhostNetwork\s*:\s*true\b|\bhostPID\s*:\s*true\b|\bhostIPC\s*:\s*true\b"), "Container shares host namespace"),
    ("SEC008", re.compile(r"(?i)\bimage\s*:\s*['\"]?[^\s'\"]+:latest\b"), "Mutable latest image tag"),
    ("SEC009", re.compile(r"(?i)\bcurl\b[^\n|]*\|\s*(?:sudo\s+)?(?:sh|bash)\b|\bwget\b[^\n|]*\|\s*(?:sudo\s+)?(?:sh|bash)\b"), "Remote content piped directly to a shell"),
]
TEXT_SUFFIXES = ALLOWED_SUFFIXES | {".dockerfile", ".tfvars", ".lock", ".properties", ".env.example"}


def workspace_path(raw: str | Path) -> Path:
    path = Path(raw).expanduser()
    try:
        absolute = Path(os.path.abspath(str(path)))
    except (OSError, ValueError) as exc:
        raise ValueError(f"Invalid workspace path: {exc}") from exc
    if _has_symlink_component(absolute):
        raise ValueError("Workspace path includes a symlink; choose a direct, non-symlink path.")
    if not absolute.exists() or not absolute.is_dir():
        raise ValueError("Workspace must be an existing directory.")
    return absolute.resolve(strict=True)


def walk_files(root: Path, max_files: int = MAX_SCAN_FILES) -> tuple[list[Path], bool]:
    found: list[Path] = []
    truncated = False
    for dirname, dirnames, filenames in os.walk(root, topdown=True, followlinks=False):
        base = Path(dirname)
        kept = []
        for name in dirnames:
            child = base / name
            if name.casefold() in IGNORED_DIRS or child.is_symlink():
                continue
            kept.append(name)
        dirnames[:] = kept
        for name in filenames:
            path = base / name
            if path.is_symlink() or not path.is_file():
                continue
            found.append(path)
            if len(found) >= max(1, min(int(max_files), MAX_SCAN_FILES)):
                truncated = True
                return found, truncated
    return found, truncated


def _relative(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root)).replace("\\", "/")
    except ValueError:
        return path.name


def inspect_tree(root: Path, max_files: int = 250) -> dict[str, Any]:
    files, truncated = walk_files(root, max_files=max_files)
    ext_counts = Counter((p.suffix.casefold() or "[no extension]") for p in files)
    entries = []
    for p in files[:min(max_files, 250)]:
        try:
            size = p.stat().st_size
        except OSError:
            size = -1
        entries.append({"path": _relative(p, root), "bytes": size})
    return {"workspace": str(root), "files_seen": len(files), "truncated": truncated,
            "extensions": dict(ext_counts.most_common(20)), "entries": entries}


def python_syntax(root: Path, max_files: int = 1000) -> dict[str, Any]:
    files, truncated = walk_files(root, max_files=max_files)
    candidates = [p for p in files if p.suffix.casefold() == ".py"]
    checked, errors, oversized = 0, [], []
    for path in candidates:
        rel = _relative(path, root)
        try:
            if path.stat().st_size > DEFAULT_FILE_BYTES:
                oversized.append(rel)
                continue
            raw = path.read_bytes()
            if b"\x00" in raw:
                errors.append({"path": rel, "line": 0, "message": "NUL byte detected; skipped as non-text"})
                continue
            source = raw.decode("utf-8-sig")
            ast.parse(source, filename=rel, mode="exec")
            checked += 1
        except SyntaxError as exc:
            errors.append({"path": rel, "line": exc.lineno or 0, "message": exc.msg})
        except (OSError, UnicodeError, ValueError) as exc:
            errors.append({"path": rel, "line": 0, "message": f"Could not inspect file: {type(exc).__name__}"})
    return {"tool": "python-syntax", "workspace": str(root), "checked": checked,
            "candidate_files": len(candidates), "errors": errors, "oversized_skipped": oversized,
            "scan_truncated": truncated, "ok": not errors}


def secret_scan(root: Path, max_files: int = 1000) -> dict[str, Any]:
    files, truncated = walk_files(root, max_files=max_files)
    findings: list[dict[str, Any]] = []
    scanned = 0
    for path in files:
        name = path.name.casefold()
        # Never open conventional secret stores or credential-named files.
        if name in {".env", ".netrc", "credentials", "credentials.json", "secrets.yaml", "secrets.yml"} or any(
            word in name for word in ("secret", "credential", "password", "id_rsa", "id_ed25519", "private_key", "service-account", "service_account", "token", "api_key", "apikey")
        ):
            findings.append({"path": _relative(path, root), "line": 0, "rule": "filename-review",
                             "message": "Sensitive-looking filename was not opened"})
            continue
        if path.suffix.casefold() not in TEXT_SUFFIXES and name not in {"dockerfile", ".env.example"}:
            continue
        try:
            if path.stat().st_size > DEFAULT_FILE_BYTES:
                continue
            raw = path.read_bytes()
            if b"\x00" in raw:
                continue
            content = raw.decode("utf-8-sig")
        except (OSError, UnicodeError):
            continue
        scanned += 1
        for line_no, line in enumerate(content.splitlines(), 1):
            if any(pattern.search(line) for pattern in SECRET_PATTERNS):
                # Intentionally never return line content or matched values.
                findings.append({"path": _relative(path, root), "line": line_no,
                                 "rule": "possible-secret", "message": "Possible credential/private-key pattern; inspect locally and redact"})
                break  # One signal per file; avoid printing or collecting secret values.
    return {"tool": "secret-scan", "workspace": str(root), "files_scanned": scanned,
            "findings": findings, "scan_truncated": truncated,
            "note": "Best-effort pattern scan, not proof that the workspace is secret-free."}


def config_scan(root: Path, max_files: int = 2000) -> dict[str, Any]:
    files, truncated = walk_files(root, max_files=max_files)
    candidates = [p for p in files if p.suffix.casefold() in {".tf", ".tfvars", ".yaml", ".yml", ".json", ".toml", ".ini", ".conf", ".cfg", ".sh", ".bash", ".py", ".properties", ".dockerfile", ".service"} or p.name.casefold() in {"dockerfile", "docker-compose.yml", "docker-compose.yaml", "containerfile"}]
    findings: list[dict[str, Any]] = []
    scanned = 0
    for path in candidates:
        try:
            if path.stat().st_size > DEFAULT_FILE_BYTES:
                continue
            raw = path.read_bytes()
            if b"\x00" in raw:
                continue
            lines = raw.decode("utf-8-sig").splitlines()
        except (OSError, UnicodeError):
            continue
        scanned += 1
        for number, line in enumerate(lines, 1):
            # Skip simple comment-only lines to reduce noise; this is deliberately not a parser.
            if line.lstrip().startswith(('#', '//', ';')):
                continue
            for rule_id, pattern, explanation in CONFIG_RULES:
                if pattern.search(line):
                    findings.append({"path": _relative(path, root), "line": number,
                                     "rule": rule_id, "message": explanation})
    return {"tool": "config-scan", "workspace": str(root), "files_scanned": scanned,
            "findings": findings, "scan_truncated": truncated,
            "note": "Heuristic checks only. Review context; false positives and missed issues are possible."}


def git_status(root: Path) -> dict[str, Any]:
    git = shutil.which("git")
    if not git:
        return {"tool": "git-status", "ok": False, "message": "Git executable not found."}
    if not (root / ".git").exists():
        return {"tool": "git-status", "ok": False, "message": "Workspace does not appear to be a Git repository."}
    env: dict[str, str] = {"GIT_CONFIG_NOSYSTEM": "1", "GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C"}
    for key in ("PATH", "SYSTEMROOT", "WINDIR", "HOME", "USERPROFILE", "TEMP", "TMP"):
        if key in os.environ:
            env[key] = os.environ[key]
    try:
        result = subprocess.run([git, "-c", "core.fsmonitor=false", "status", "--short", "--branch"],
                                cwd=root, env=env, capture_output=True, text=True, timeout=12,
                                check=False, shell=False)
        return {"tool": "git-status", "ok": result.returncode == 0,
                "returncode": result.returncode, "stdout": result.stdout[:12000],
                "stderr": result.stderr[:3000]}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"tool": "git-status", "ok": False, "message": f"Git status failed: {type(exc).__name__}"}


def run_test_suite(root: Path, allow_code_execution: bool) -> dict[str, Any]:
    if not allow_code_execution:
        raise ValueError("Running a project test suite executes its code. Re-run with --allow-code-execution only if you trust this workspace.")
    env: dict[str, str] = {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"}
    for key in ("PATH", "SYSTEMROOT", "WINDIR", "HOME", "USERPROFILE", "TEMP", "TMP"):
        if key in os.environ:
            env[key] = os.environ[key]
    started = time.monotonic()
    try:
        proc = subprocess.run([sys.executable, "-m", "unittest", "discover", "-v"], cwd=root,
                              env=env, capture_output=True, text=True, timeout=180, check=False, shell=False)
        return {"tool": "run-tests", "ok": proc.returncode == 0, "returncode": proc.returncode,
                "duration_seconds": round(time.monotonic() - started, 2),
                "stdout": proc.stdout[-12000:], "stderr": proc.stderr[-18000:],
                "note": "Test code was executed with the current OS user's permissions; this tool is not a sandbox."}
    except subprocess.TimeoutExpired as exc:
        return {"tool": "run-tests", "ok": False, "timeout": True,
                "duration_seconds": round(time.monotonic() - started, 2),
                "stdout": str(exc.stdout or "")[-3000:], "stderr": str(exc.stderr or "")[-5000:],
                "note": "Test execution timed out; the process was terminated by the subprocess timeout handler."}


def available_tools() -> list[dict[str, str]]:
    return [
        {"name": "inspect-tree", "risk": "read-only", "description": "Summarize files and extensions without opening file contents."},
        {"name": "python-syntax", "risk": "read-only", "description": "Parse Python files into ASTs; does not execute source code."},
        {"name": "secret-scan", "risk": "read-only", "description": "Best-effort secret-pattern scan; output never includes matched values."},
        {"name": "config-scan", "risk": "read-only", "description": "Heuristic scans for common risky container/cloud configuration patterns."},
        {"name": "git-status", "risk": "read-only", "description": "Show Git status without invoking a shell."},
        {"name": "run-tests", "risk": "executes-code", "description": "Runs Python unittest discovery; requires explicit --allow-code-execution."},
    ]


def run_tool(name: str, raw_workspace: str | Path, *, max_files: int = 1000,
             allow_code_execution: bool = False) -> dict[str, Any]:
    root = workspace_path(raw_workspace)
    if name == "inspect-tree":
        return inspect_tree(root, max_files=min(250, max_files))
    if name == "python-syntax":
        return python_syntax(root, max_files=max_files)
    if name == "secret-scan":
        return secret_scan(root, max_files=max_files)
    if name == "config-scan":
        return config_scan(root, max_files=max_files)
    if name == "git-status":
        return git_status(root)
    if name == "run-tests":
        return run_test_suite(root, allow_code_execution)
    raise ValueError(f"Unknown tool '{name}'. Run `tools list` to see available tools.")


def format_tool_result(result: dict[str, Any]) -> str:
    """Format results without ever printing source lines that might contain secrets."""
    import json
    return json.dumps(result, indent=2, ensure_ascii=False)


def cmd_tools_list(_args: Any) -> None:
    print("AION local engineering tools (no arbitrary shell execution):")
    for tool in available_tools():
        print(f"- {tool['name']:<16} risk={tool['risk']:<13} {tool['description']}")
    print("Use: tools run NAME --workspace PATH. `run-tests` also requires --allow-code-execution.")


def cmd_tool_run(args: Any) -> None:
    import json
    result = run_tool(args.name, args.workspace, max_files=args.max_files,
                      allow_code_execution=args.allow_code_execution)
    print(json.dumps(result, indent=2, ensure_ascii=False))

# Third-party notices and dependency inventory

Last reviewed: 2026-10-24
Release: AION Zero 0.4.0 public-prep package

## Application runtime

The AION Zero runtime source files import Python standard-library modules and
other modules included in this repository. The project has no `requirements.txt`
and does not require an install of third-party Python packages for its core runtime.
Python itself is distributed separately; consult the license supplied by your Python
installer/distribution.

## Optional local AI runtime and models

- **Ollama** is an optional external local model runtime. It is not bundled by this
  project. Review Ollama's current license and distribution terms before redistributing
  it or including it in an installer.
- **Embedding and chat model weights** are not bundled. Each model can have separate
  terms, usage restrictions, attribution conditions, and redistribution rules. Review
  the exact model card/license for every model you download or recommend before use.
- AION's local API integration is configured for loopback access. This does not change
  the license terms of Ollama or any model.

## Development and CI

The GitHub Actions workflow references `actions/checkout` and `actions/setup-python`
by major version. These are hosted CI actions and are not copied into the application
runtime archive as libraries. Their respective upstream repositories and licenses
should be checked when changing the workflow.

## Verification status

This is a preliminary inventory based on imports and files in the release tree, not a
formal software-composition analysis or legal opinion. Re-run a dependency and license
scan whenever third-party code, packages, fonts, images, model weights, or generated
artifacts are added. Do not add assets unless their provenance and license are recorded.

<!-- SPDX-License-Identifier: Apache-2.0 -->

# AION Zero — Offline Engineering Intelligence

**Version:** 0.4.0 engineering memory, finance, audit and bounded local execution  
**Budget:** $0 in software/license costs  
**Runtime:** Python 3.10+ and SQLite; standard library only  
**Network required at runtime:** No for core memory, ingestion, search, task journaling, backup, restore, export, or diagnostics.

AION Zero is an offline-first engineering assistant for Python, Linux/IT, cloud, DevOps, containers, reliability, databases, networking, Git and defensive cybersecurity. It combines compressed SQLite memory, keyword and optional semantic retrieval, persistent task history, evidence-based procedures, 19 bundled engineering skill packs, and an optional local Ollama planning agent.

> Honest boundary: this is not a trained foundation model or production-certified autonomous operator. `agent` drafts plans. `autopilot` can coordinate only a small allowlist of local diagnostics; it never executes model-generated shell commands, makes payments, edits source files, deploys infrastructure, or submits legal/tax documents. Finance reports are bookkeeping helpers, and the legal register is a deadline tracker. The opt-in test runner executes project test code with your OS user's permissions and is not a sandbox. Agent plans are automatically journaled as unverified tasks unless `--no-save` is specified. AI inference and semantic embeddings require local Ollama plus downloaded models; core memory and read-only tools do not require internet access.

## Security reporting

Please report suspected vulnerabilities privately to deez2nutsmaster@gmail.com. See `SECURITY.md` before sending details; do not include credentials or live secrets.

## Maintainer and project links

AION Zero is maintained by **Junior Justin Amusa**, based in Pretoria, South Africa (SAST, UTC+02:00). See [`MAINTAINER.md`](MAINTAINER.md) for the maintainer profile and links.

- **GitHub:** [Aightbet138](https://github.com/Aightbet138)
- **LinkedIn:** [Junior Justin Amusa](https://www.linkedin.com/in/junior-justin-amusa-6914563b3)
- **ORCID:** [0009-0006-9060-3164](https://orcid.org/0009-0006-9060-3164)
- **X:** [@cloudwithjnr](https://x.com/cloudwithjnr)
- **Email:** [deez2nutsmaster@gmail.com](mailto:deez2nutsmaster@gmail.com)

## License and third-party components

**Copyright © 2026 Junior Justin Amusa.** AION Zero project code and documentation are offered under Apache License 2.0 unless a file states otherwise.

This package designates the **Apache License 2.0** for AION Zero project code and documentation unless a file states otherwise; see [`LICENSE`](LICENSE) and [`NOTICE`](NOTICE). Before publishing, confirm that you own or are authorized to license all included material and update attribution as needed using [`PUBLISH_CHECKLIST.md`](PUBLISH_CHECKLIST.md). Optional Ollama software and AI model weights are separate and may have different terms; see [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). No model weights are included in this project archive.

## Quick start — Windows

Open PowerShell or Command Prompt in this folder.

```powershell
py --version
py aion.py init
py aion.py skills list
py aion.py skills seed
py -m unittest -v
```

Save a lesson and search for it:

```powershell
py aion.py add "Deployment lesson" --kind lesson --category devops --tags "docker,testing" --body "Run a health check and regression tests before calling a deployment successful."
py aion.py search "deployment health check"
py aion.py ask "What deployment checks do we remember?"
```

The default database is `data/aion.sqlite3` next to the script. To place memory somewhere else, set `AION_DATA_DIR` before running the app.

Keyword search needs no AI model. Semantic search is an optional local feature; follow the setup below after installing Ollama and downloading its embedding model.

## Quick start — Linux/macOS

```bash
python3 --version
python3 aion.py init
python3 aion.py skills list
python3 aion.py skills seed
python3 -m unittest -v
python3 aion.py add "Deployment lesson" --kind lesson --category devops --tags "docker,testing" --body "Run a health check and regression tests before calling a deployment successful."
python3 aion.py search "deployment health check"
```

## Main commands

| Goal | Command |
|---|---|
| Initialize/check local database | `py aion.py init` |
| Save a note | `py aion.py add "Title" --body "Text" --kind knowledge --category python` |
| Import text/code from a selected folder | `py aion.py ingest .\learning-notes --category python` |
| Search local memory | `py aion.py search "connection refused"` |
| Index semantic embeddings | `py aion.py embeddings index --model all-minilm` |
| Search by meaning | `py aion.py search "the service keeps dying" --mode semantic --embedding-model all-minilm` |
| Combine semantic and keyword ranking | `py aion.py search "container liveness failure" --mode hybrid --embedding-model all-minilm` |
| Inspect semantic indexes | `py aion.py embeddings stats` |
| See one record | `py aion.py show 1` |
| List recent memories | `py aion.py list --limit 30` |
| Record a tested procedure | `py aion.py procedure add "Restart lab service" --prerequisites "Lab VM; access available" --steps "Restart service, then check status" --expected "Service healthy" --risks "Brief interruption" --rollback "Restore previous config"` |
| Start an engineering task | `py aion.py task start "Fix build" --objective "Make tests pass" --environment "Local Windows lab" --versions "Python 3.12" --category devops` |
| Add a hypothesis/action/test | `py aion.py task update 1 --field actions --value "Checked the CI log"` |
| Close the task with evidence | `py aion.py task close 1 --outcome success --validation "All 42 unit tests passed" --lesson "Add regression test for the original bug" --solution "See verified procedure after review"` |
| Mark a record as tested | `py aion.py verify 1 --status tested --evidence "Test suite passed on the stated lab version"` |
| Promote tested record to verified | `py aion.py verify 1 --status verified --evidence "Independent repeat run succeeded" --confidence 0.95` |
| Show record relationships | `py aion.py link 1 2 --relation supports` then `py aion.py related 1` |
| View change history | `py aion.py history 1` |
| Storage stats | `py aion.py stats` |
| Create a checked backup | `py aion.py backup backups\aion.sqlite3` |
| Restore a backup | `py aion.py restore backups\aion.sqlite3 --yes` |
| Export records | `py aion.py export backups\memory.jsonl.gz --gzip` |
| Diagnostics (no network requests) | `py aion.py doctor` |
| List bundled engineering skills | `py aion.py skills list` |
| Seed skills into memory | `py aion.py skills seed` |
| Evaluate skill routing offline | `py aion.py skills evaluate` |
| Inspect a skill pack | `py aion.py skills show python_engineering` |
| Plan a task using a local chat model | `py aion.py agent "Diagnose a failed deployment" --model YOUR_LOCAL_CHAT_MODEL` |
| Generate a plan without saving it | `py aion.py agent "Review this change" --model YOUR_LOCAL_CHAT_MODEL --no-save` |
| List built-in tools | `py aion.py tools list` |
| Inspect a workspace without reading contents | `py aion.py tools run inspect-tree --workspace .` |
| Check Python syntax without executing it | `py aion.py tools run python-syntax --workspace .` |
| Heuristic defensive configuration checks | `py aion.py tools run config-scan --workspace .` |
| Best-effort secret scan (never prints matches) | `py aion.py tools run secret-scan --workspace .` |
| Git status | `py aion.py tools run git-status --workspace .` |
| Run unittest suite (executes code; opt-in) | `py aion.py tools run run-tests --workspace . --allow-code-execution` |
| Initialize a default chart of accounts | `py aion.py finance setup` |
| Add a bill (record only) | `py aion.py finance bills add "ISP" "Internet service" --amount 599.00 --currency ZAR --due 2026-11-01 --category connectivity --priority 4` |
| List and prioritize open bills | `py aion.py finance bills list --status open --currency ZAR` and `py aion.py finance bills optimize --cash 5000 --currency ZAR --days 30` |
| Mark a bill paid in the tracker | `py aion.py finance bills pay 1 --date 2026-11-01 --reference "statement reference"` |
| Post balanced double-entry journal | `py aion.py finance entry add "Owner funding" --date 2026-10-24 --currency ZAR --line 1000:debit:1000.00 --line 3000:credit:1000.00` |
| Trial balance / P&L | `py aion.py finance trial-balance --currency ZAR`; `py aion.py finance pnl --start 2026-10-01 --end 2026-10-31 --currency ZAR` |
| Set and review budget | `py aion.py finance budget set software-cloud --period 2026-10 --limit 500 --currency ZAR`; `py aion.py finance budget report --period 2026-10 --currency ZAR` |
| Legal/compliance deadline register | `py aion.py legal add "Contract review" --type contract --jurisdiction ZA --description "Ask counsel to review" --due 2026-11-30 --reviewer "Assigned reviewer"`; then `py aion.py legal list` |
| Verify local audit chain | `py aion.py audit verify` |
| Run an approved diagnostic and record its outcome | `py aion.py execution run python-syntax --workspace . --approve` |
| Plan bounded diagnostics, without executing | `py aion.py autopilot "Review Python security and configuration" --workspace . --plan-only` |
| Execute bounded diagnostic plan | `py aion.py autopilot "Review Python security and configuration" --workspace . --approve` |
| View experience twin and context-based estimate | `py aion.py twin report`; `py aion.py twin predict python-syntax --goal "Check Python syntax in project"` |
| Inspect real local storage capacity | `py aion.py storage report --target-pb 1` |

On Linux/macOS, replace `py` with `python3` in the commands. IDs in examples are placeholders: check the ID printed when you create a record.

## How memory works

- **Compressed bodies:** body content is stored as gzip blobs in SQLite. SHA-256 hashes support deduplication and integrity checks.
- **Search:** the available SQLite FTS5 feature indexes metadata. A separate token/frequency index searches compressed body content without storing a second full plain-text copy of each document. If FTS5 is missing from the local SQLite build, metadata search falls back to a local scan.
- **Persistent task journal:** tasks retain objective, environment, versions, hypotheses, actions, validation results, outcome, lessons, and reusable solution notes.
- **Evidence-based statuses:** `unverified`, `tested`, `verified`, `rejected`, `superseded`. A record cannot jump directly from unverified to verified. Evidence is required for status changes.
- **Revision history:** content/status changes preserve previous compressed bodies and evidence for inspection.
- **Privacy defaults:** the application doesn't send data to a hosted AI service. It uses restrictive local file permissions where supported and screens for some common secret patterns.

## Finance, bills, accounting and legal registers

The finance module records bills without paying them, produces a transparent priority recommendation against the cash amount you enter, and maintains a small double-entry ledger. Initialize the account codes before posting entries:

```powershell
py aion.py finance setup
py aion.py finance accounts
py aion.py finance bills add "Cloud Provider" "October infrastructure invoice" --amount 1200.00 --currency ZAR --due 2026-11-05 --category software-cloud --priority 4 --late-fee 50.00
py aion.py finance bills optimize --cash 2000 --currency ZAR --days 30
py aion.py finance entry add "Accrue cloud bill" --date 2026-10-24 --currency ZAR --line 5100:debit:1200.00 --line 2000:credit:1200.00
py aion.py finance trial-balance --currency ZAR
py aion.py finance budget set software-cloud --period 2026-10 --limit 1500 --currency ZAR
py aion.py finance budget report --period 2026-10 --currency ZAR
```

Journal entry lines use `ACCOUNT_CODE:debit|credit:AMOUNT` and can be repeated. Debits and credits must balance. Correct entries with `finance entry reverse ID --reason ...`, not by silently changing a posted entry. The current money CLI stores two decimal places and never converts currencies; use the currency appropriate to each entry/report. Bill recurrence is descriptive, not automatic invoice creation.

`legal add/list/complete` stores dates, jurisdiction, source references, reviewers and evidence notes. It does not tell you whether a law applies or certify compliance. Have qualified legal counsel and accounting professionals review matters that require professional judgment.

## Audited, bounded engineering execution

The standard `agent` command remains a planner. For approved, read-only orchestration, preview a local action sequence and then run it if appropriate:

```powershell
py aion.py autopilot "Review Python security and configuration" --workspace . --plan-only
py aion.py autopilot "Review Python security and configuration" --workspace . --approve
py aion.py execution history
py aion.py audit verify
```

To ask the local model to select diagnostic tool names, use `--model YOUR_LOCAL_CHAT_MODEL`; AION validates each proposed name against its allowlist. It will not execute model-written shell commands or code. `run-tests` executes project code with your OS user’s permissions and requires both `--include-tests` and `--allow-code-execution` in `autopilot` (as well as `--approve` for the run). This is not a sandbox. Human review is recorded explicitly; a green diagnostic is not proof that an environment is secure.

The `twin` command learns a small empirical per-tool outcome/runtime baseline from previous approved runs and optionally compares goal text with earlier observations. It is transparent, data-limited statistical learning—not a general-purpose neural network or an autonomous digital replica.

## Safe file ingestion

Only ingest folders or files you are authorized to keep. Begin with public documentation, your own notes, and safe code samples. Example:

```powershell
py aion.py ingest .\learning-notes --category python --tags "reference,training-notes" --max-files 200 --max-file-mib 2 --max-total-mib 50
```

The importer allowlists text/code extensions, skips common generated/dependency directories and symlinks, has per-file, total-size and file-count limits, ignores likely secret filenames, rejects binary and invalid UTF-8 content, and rejects some common credential/private-key patterns. These checks are **best-effort, not guaranteed secret detection**. Never import password stores, private keys, API tokens, browser profiles, cloud credential folders, unredacted customer data, or security logs containing sensitive identifiers.

Source files are never modified or deleted. The import process only writes local AION records.

## Local semantic retrieval and offline AI inference

The basic memory commands work without a network. Semantic search and AI-generated answers need an explicitly installed local Ollama service listening on `127.0.0.1:11434`. Install Ollama and download models while internet access is available; after that, AION can run the retrieval workflow offline. AION calls only the hard-coded loopback endpoint, not a hosted embedding API.

Install a small embedding model once (the software and model are free; download uses bandwidth and disk space):

```powershell
ollama pull all-minilm
ollama list
py aion.py embeddings index --model all-minilm
py aion.py embeddings stats
py aion.py search "the service keeps dying" --mode semantic --embedding-model all-minilm
py aion.py search "container liveness failure" --mode hybrid --embedding-model all-minilm
```

Use the same model name when indexing and searching. After adding knowledge, run `embeddings index` again; unchanged records are skipped. If the local model itself changes, force a rebuild with `py aion.py embeddings index --model all-minilm --force`. Vector search currently performs exact cosine comparisons in Python, so it scales linearly with the number of stored chunks; this is an early local prototype, not a massive vector database.

For local AI-generated answers, download a separate chat model if your computer can run one:

```powershell
ollama list
py aion.py ask "Explain the safest way to troubleshoot a failed deployment" --model YOUR_INSTALLED_CHAT_MODEL --mode hybrid --embedding-model all-minilm
```

`search` with default `--mode lexical`, `doctor`, and core memory-management commands do not contact Ollama or the internet. `embeddings index`, `search --mode semantic`, `search --mode hybrid`, and `ask --mode semantic|hybrid` explicitly contact Ollama on loopback. Model quality and speed depend on your PC's RAM, CPU/GPU, and available storage.

## Backups, exports and recovery

Back up regularly to a separate drive when possible. `backup` uses SQLite's backup API and validates the database. `restore` validates the backup and refuses to overwrite an existing database unless you pass `--yes`; before replacing the active database it makes a timestamped safety copy. JSONL export contains decoded record bodies and must be protected like the original records. Keep backups private.

## Limitations and next milestones

Current v0.4 capabilities:
- Compressed local records, duplicate detection, lexical search and optional semantic retrieval
- Bounded text/code ingestion, provenance, secret-pattern screening and backups
- Task journals, outcome lessons, record links, status evidence and revisions
- 19 bundled skill packs covering engineering, Python, Linux/SRE, networking, defensive cybersecurity, cloud, DevOps/CI/CD, containers/Kubernetes, databases/storage, observability/incident response, Git/release hygiene, IT support, secure code review, finance/accounting, bills/cash flow, legal/compliance registers, bounded autonomy, experience twins, and storage/compute capacity
- Local Ollama planning agent that combines relevant skills, memory, and optional read-only workspace metadata
- Allowlisted diagnostics: file tree summary, Python syntax parse (no execution), best-effort secret scan, heuristic config scan, Git status, and opt-in unittest execution
- Deterministic offline skill-routing benchmark (14/14 curated cases at release; coverage-only, not proof of real-world skill correctness)
- Automated tests for the new skills, auto-recorded agent plans, local endpoint boundary and tool safety

Not yet implemented:
- Fine-tuning or changing model parameters from experience; the current twin is a small empirical/statistical baseline
- Source-code edits, deployments, incident remediation, real payment initiation, direct bank integration, external legal/tax filings, or arbitrary command execution
- Strong sandboxing for code/tests, multi-user permissions, externally signed audit events, production hardening, or certified accounting/security/legal compliance
- Guaranteed detection of secrets, vulnerabilities, malicious instructions, or broken configurations
- A live embedding/chat model bundled with the project; live inference must be tested on the target PC

Before public publication, finish the checklist in `PUBLISH_CHECKLIST.md`, select a license, test on target operating systems and hardware, and arrange independent security/accounting/legal review where applicable.

## Tests

Run the regression suite from this directory:

```powershell
py -m unittest -v
```

Tests create their own temporary databases and synthetic sample data. They cover persistence, migration, deduplication, compression, lexical search, semantic chunk coverage, embedding serialization/indexing, query-to-record ranking with a deterministic fake model, stale-vector invalidation, loopback-only API targeting, evidence-gated statuses, task history, ingestion defenses, symlink rejection, backup/restore, export, and proof that the core path does not attempt network connections. Tests do not require Ollama or a downloaded model.

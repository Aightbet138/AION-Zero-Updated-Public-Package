# AION Zero 0.4.0 public-release checklist

This is a release-preparation checklist, not a certification. A repository owner must complete the maintainer-specific items below before publishing.

## License and provenance — required before public release

- [ ] Junior Justin Amusa confirms they own or have permission to license all code, skill packs, documentation, test fixtures, icons/assets, and generated content in this distribution; add other rights holders where applicable.
- [ ] Confirm Apache License 2.0 is the intended license. It permits use, modification, redistribution, and commercial use subject to its conditions; it does not stop others selling their own derivatives.
- [ ] Verify that `LICENSE`, `NOTICE`, `MAINTAINER.md`, and README attribution accurately reflect the actual rights holders. Do not claim ownership of third-party code.
- [ ] Keep `LICENSE`, `NOTICE`, and `THIRD_PARTY_NOTICES.md` in the repository and release archive.
- [ ] Audit git history and any older archives for accidentally committed secrets or private data. Deleting a file from the latest tree does not remove it from commit history.
- [ ] Confirm there are no unreviewed fonts, images, external code snippets, model weights, or third-party assets.

## Repository configuration — required before announcement

- [ ] Create repository and set repository description, topics, supported platforms, and maintainer identity.
- [ ] Enable Issues only if someone can review them; otherwise document an alternative support path.
- [ ] Confirm deez2nutsmaster@gmail.com is controlled by the maintainer and monitored before launch; alternatively/also enable GitHub private vulnerability reporting after the repository is created. Do not claim the email inbox or GitHub channel is monitored until verified.
- [ ] Decide who will triage issues/security reports and how inactive maintainers are handled.
- [ ] Decide whether contributions are accepted under Apache-2.0 and whether a Contributor License Agreement is needed later.
- [ ] Choose a release version and tag only the reviewed commit. Publish checksums for release archives.

## Maintainer profile

- [ ] Confirm the public contact details in `MAINTAINER.md` are correct and that the maintainer is comfortable publishing the location and social/profile links.
- [ ] Confirm the security email is controlled and monitored.
- [ ] Confirm public profile URLs are accurate; the timezone should be represented as SAST (UTC+02:00), not as a time-of-day that will become stale.

## Technical qualification

- [ ] Run `python -m py_compile aion.py aion_skills.py aion_tools.py aion_enterprise.py test_aion.py`.
- [ ] Run `python -m unittest -v test_aion.py` on clean Windows and Linux environments.
- [ ] Verify CI actually passes on the supported Python/platform matrix; a workflow file alone is not proof.
- [ ] Test initialization, backup, restore, database migrations, permissions, finance balance checks, audit verification, and CLI error messages using synthetic data.
- [ ] Validate at least one live local chat model and one embedding model on stated hardware; record RAM/VRAM, speed, and model licenses. Mocks are not a live-model quality test.
- [ ] Review authorization boundaries, secret handling, path traversal, SQLite migration, audit chain, prompt injection, local-model access and test execution.
- [ ] Keep `data/`, databases, backups, exports, logs, model weights and local configuration out of source control and release archives.

## User documentation and risk boundaries

- [ ] Document supported Python versions/OS, known limitations, storage location, backup/restore, data deletion, and error reporting.
- [ ] Keep the warning that the test runner executes code with current OS user permissions and is not a sandbox.
- [ ] Keep finance/legal disclaimers; have qualified professionals review any workflows intended for production accounting, tax or legal use.
- [ ] Do not claim petabyte-scale capacity, certified security, autonomous production operations, or model self-training. These are not implemented merely by adding a planning or memory feature.
- [ ] Check every optional model/runtime's separate terms before recommending, downloading or distributing it.

## Known boundaries in v0.4.0

- Local single-user application; not a multi-tenant service.
- Finance is user-entered tracking/reporting; no bank connection or payment initiation.
- Legal/compliance register is a reminder/evidence store; not legal advice or a compliance certification.
- Audit hash chain is locally verifiable and tamper-evident, not tamper-proof or externally anchored.
- Execution is limited to fixed diagnostics. Test execution is not sandboxed.
- Experience twin is a simple statistical baseline, not a general learned world model.
- Petabyte storage, distributed inference, and specialized hardware scheduling are not implemented.

## Publication status

Until the owner-confirmation and repository-configuration checkboxes are completed, describe the package as a **public-prep alpha**, not as production-certified software.

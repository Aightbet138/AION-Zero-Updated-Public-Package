<!-- SPDX-License-Identifier: Apache-2.0 -->

# AION Zero architecture — v0.4.0

## Components

- **CLI (`aion.py`)**: local-first entry point for compressed knowledge memory, task journal, keyword/semantic retrieval, skill packs, planning and diagnostics.
- **Memory store (SQLite)**: gzip-compressed record bodies, token-frequency index, evidence-gated status changes, relationships, revision snapshots and optional chunk-level local embeddings.
- **Skill packs (`skillpacks/*.md`)**: 19 bundled engineering, security, finance, bill-management, accounting, legal-register, autonomy, digital-twin and scalable-infrastructure guides. They are reference guides, not proof of professional qualification.
- **Local planner (`aion_skills.py`)**: uses bundled skill selection, local memory and optional read-only workspace inventory. Ollama is addressed only on `127.0.0.1:11434`. The original `agent` command drafts plans; `autopilot` can optionally ask the local model to select only tool names from a fixed allowlist.
- **Diagnostics (`aion_tools.py`)**: bounded file inventory, Python AST syntax parsing, best-effort secret scan, heuristic configuration scan, Git status, and explicitly opt-in unit-test execution.
- **Operations module (`aion_enterprise.py`)**: bill tracker and heuristic payment prioritization; double-entry bookkeeping; chart of accounts, trial balance, P&L and category budgets; legal/compliance deadline register; append-only hash-chained audit events; approval-gated execution run history; local experience-twin statistics; and real local-storage capacity reporting.
- **Local inference**: no hosted AI endpoints. Chat and embedding models must be downloaded in advance. SQLite memory, finance records, bill optimizer, audit verification, offline deterministic autopilot selection and read-only diagnostics need no model.

## Data model and trust

The base SQLite schema stores memory records, body terms, revision snapshots, relations and optional embeddings. Operations schema adds bills, accounts, journal entries/lines, budgets, legal items, audit events, execution runs and experience observations. It is initialized lazily in the same local database.

New knowledge and skill records remain `unverified` until evidence supports a transition. Model-generated plans are unverified. Procedures must not become trusted merely by being retrieved more often. Imported text and model outputs are untrusted data, not policy.

## Finance/accounting model

- Money is stored as integer minor units (two decimal places in the current CLI) rather than binary floating point.
- Each posted journal entry is double-entry and balanced by currency. Corrections are made with reversing entries, preserving the original and correction in the ledger.
- Trial balance and income/expense reports are derived from posted journal lines. Budget reports compare posted expense actuals and open bill commitments by category and month.
- The bill optimizer ranks manually recorded bills using due date, priority, recorded late fee and available cash; it is a transparent heuristic, not an optimizer for all obligations. It never pays bills, contacts banks, validates invoices, or decides that a bill is legally owed.
- Recurrence is a classification field for reporting; this release does not automatically create future invoice instances.
- Reports are bookkeeping aids; they are not certified financial statements, tax filings or regulated financial advice. Currency conversions are not performed.

## Legal/compliance register

Legal items contain a manually supplied jurisdiction, source reference, reviewer, deadline, status and evidence. The register can flag dates, but it does not determine legal applicability, interpret contracts, calculate statutory deadlines, file anything, or certify compliance. Qualified counsel/compliance staff must review legal conclusions.

## Auditing

Business mutations and approved diagnostic executions append SHA-256 hash-chained audit records. The database triggers prevent routine SQL `UPDATE`/`DELETE` operations on audit rows, and `audit verify` checks chain links and hashes. This is tamper-evident, not tamper-proof against an administrator who can alter the database, remove triggers, or modify the application. For stronger assurance, export signed logs to independently controlled storage; external signing/key management is not implemented here.

## Bounded autonomy and verified execution

- No model-generated shell command or arbitrary code is executed by AION.
- `execution run` requires an explicit `--approve` and accepts only a fixed tool allowlist.
- `autopilot` caps the number of actions, chooses from the same tool allowlist, requires approval for a run, and can be run with `--plan-only`. If a local model is supplied, its action proposal is parsed and rejected unless each action is explicitly allowlisted; generated commands, tool arguments and deployment steps are never accepted.
- `run-tests` runs project code with the current OS user's rights, is not a sandbox, and requires both approval and `--allow-code-execution`.
- Execution outcomes, durations, tool names, result hashes and safe aggregate summaries are stored. Raw stdout/stderr and full diagnostic contents are not persisted by the new run recorder. A human `execution review` is a review record, not a claim that the whole environment is secure.

## Experience twin

The `twin` feature learns simple per-tool empirical outcomes and runtimes from recorded executions using a transparent Beta(1,1)-smoothed rate. Optional goal matching uses token-set/Jaccard similarity against prior objectives and a weighted estimate. It is a lightweight online statistical baseline, not a trained neural network, a full digital replica, or a reliable forecast when observations are sparse. It must not authorize high-impact actions.

## Storage and compute capacity

`storage report` measures actual local directory and filesystem capacity. Compression and indexing reduce some storage costs, but AION cannot synthesize CPU, RAM, network bandwidth, disks or petabytes. Distributed storage, sharding, multi-machine inference, GPU scheduling and cloud resource provisioning are not implemented. Petabyte-class capability would require real hardware/infrastructure and associated cost.

## Known limitations and publication boundary

- Live Ollama inference and model quality have not been validated on the user's target computer by automated tests in this container.
- Semantic exact-nearest-neighbor search scales linearly with stored chunks.
- Secret/config scans are heuristic, can miss issues and can produce false positives.
- Autopilot actions are diagnostic/reporting operations, not automatic code edits, system remediation, deployments, financial transactions or legal filings.
- Finance/legal modules have automated tests but are not certified, reconciled against a real bank/accounting system, or checked against current jurisdiction-specific laws.
- No independently isolated sandbox, multi-tenant access control, externally signed audit trail, real cloud-provider billing integration, or public security review is included.
- No claims are made of matching arbitrary clusters of computers or providing petabyte storage with a zero hardware budget.

# Support

AION Zero is an early-stage community project. Support is provided on a best-effort basis; no response time or
ongoing maintenance guarantee is offered.

## Before asking for help

1. Read `README.md` and `OFFLINE_SETUP.md`.
2. Run `py aion.py doctor` (Windows) or `python3 aion.py doctor` (Linux/macOS).
3. Run the test suite and capture the exact command, operating system, Python version, and full traceback.
4. Redact machine names, usernames, file paths if sensitive, network addresses, tokens, customer data, and all secrets.

## Where to ask

After the repository URL and issue tracker are configured, use the public issue tracker for reproducible bugs and
feature requests. Do not use a public issue for security vulnerabilities or sensitive operational data; follow
`SECURITY.md` instead.

This project does not currently promise commercial support, service-level agreements, incident response, or
compatibility with every OS, model, or hardware configuration.

## Maintainer contact

Project maintainer: **Junior Justin Amusa**, Pretoria, South Africa (SAST, UTC+02:00).

- Email: [deez2nutsmaster@gmail.com](mailto:deez2nutsmaster@gmail.com)
- GitHub: https://github.com/Aightbet138
- LinkedIn: https://www.linkedin.com/in/junior-justin-amusa-6914563b3
- ORCID: https://orcid.org/0009-0006-9060-3164
- X: https://x.com/cloudwithjnr

Contact details do not imply a guaranteed response time or commercial support commitment.

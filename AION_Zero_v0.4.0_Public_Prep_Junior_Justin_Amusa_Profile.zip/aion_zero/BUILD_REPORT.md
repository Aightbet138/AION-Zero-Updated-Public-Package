<!-- SPDX-License-Identifier: Apache-2.0 -->

# AION Zero v0.4.0 — Build and validation report

## Release contents
- Compressed local SQLite memory, revision history, evidence-gated status transitions, keyword search and optional semantic retrieval.
- 19 bundled engineering reference packs across engineering, defensive security, finance/accounting, bill management, legal/compliance registers, bounded autonomy, simulation/twin and infrastructure.
- Optional local Ollama planner/embedding support (no hosted API configured).
- Allowlisted local engineering diagnostics plus plan-only/approved bounded diagnostic orchestration.
- Local bills and cash-flow prioritization, double-entry bookkeeping, chart of accounts, trial balance, P&L and category budgets.
- Legal/compliance deadline register, tamper-evident local hash chain, human-reviewed execution records, and transparent empirical experience-twin summaries.
- Actual local storage report with no claim of synthetic capacity.
- Publication/privacy/security docs and a GitHub Actions test workflow.

## Validation performed
- `python -m py_compile aion.py aion_skills.py aion_tools.py aion_enterprise.py test_aion.py` passed.
- **39 automated tests passed** (`python -m unittest -v test_aion.py`). The suite includes finance/billing, budget/P&L, balanced entries and reversals, legal register, audit tamper detection, approval-gated execution, autopilot allowlist enforcement, twin estimates, base memory/search/ingestion tests, migration, backups and semantic retrieval tests.
- Skill-routing coverage benchmark: 14/14 curated cases passed. It only evaluates this small deterministic test set.
- CLI and finance/execution smoke tests passed under isolated temporary data directories.
- Mocked local-model planning verifies the model's proposed action names are constrained by an allowlist and forbidden actions are discarded.
- Ollama requests remain pinned to loopback; no hosted model endpoint is configured.

## Not verified here
- Actual live inference speed/quality on the user's computer.
- Finance reports against real bank feeds, a qualified accountant's expectations, or audited statements.
- Legal register behavior against any current jurisdiction-specific obligation; it is a tracker only.
- Real cloud-provider billing integrations, actual payment automation, production deployments or automatic source-code remediation.
- Petabyte-scale performance or multi-node/distributed storage/compute.
- Full security assurance. Hash chains are tamper-evident only; heuristic scans can miss risks; opt-in test execution is not sandboxed.

## Runtime boundary
Core memory, local finance records/reports, audit verification, storage measurements and deterministic diagnostic routing use Python's standard library and local SQLite. Local-model planning and semantic embeddings require Ollama and previously downloaded models. AION does not contact a bank, transfer money, submit legal/tax documents, make binding legal/accounting judgments, or execute arbitrary model-generated commands.

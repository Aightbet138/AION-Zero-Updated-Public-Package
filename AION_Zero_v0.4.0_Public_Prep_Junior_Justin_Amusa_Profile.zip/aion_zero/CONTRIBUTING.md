# Contributing to AION Zero

Thanks for helping improve AION Zero. The project is an early, local-first engineering
assistant. Contributions should improve reliability, privacy, safety, testability, or
documented user value.

## Before opening a change

1. Search existing issues and pull requests when the repository is published.
2. For substantial changes, open an issue or discussion first to agree on scope.
3. Do not include credentials, private keys, real customer records, personal data,
   private infrastructure details, or proprietary files in issues, tests, fixtures, or
   pull requests.
4. Never run security tests against systems you do not own or have explicit permission
   to assess.

## Development expectations

- Prefer the Python standard library unless a new dependency has a clear benefit.
- Preserve offline operation for core workflows.
- Keep generated output deterministic where reasonable and avoid network access in tests.
- Add regression tests for bug fixes and new behavior.
- Document changes to CLI commands, storage formats, security boundaries, and data handling.
- Treat ingested files and model output as untrusted input.
- Never weaken approval checks, secret handling, audit logic, or path boundaries to make a test pass.
- Run before submitting:

  ```bash
  python -m py_compile aion.py aion_skills.py aion_tools.py aion_enterprise.py test_aion.py
  python -m unittest -v test_aion.py
  ```

- Explain what was tested, the environment used, known limitations, and any migration impact.

## Licensing contributions

By intentionally submitting a contribution for inclusion, you agree that your contribution
is submitted under the repository's Apache License 2.0, unless you and the maintainers agree
otherwise in writing. You retain your copyright in your contribution. You must have the right
to submit the contribution and must identify any copied or adapted third-party material and
its license. Do not submit code or documentation whose licensing or provenance you cannot verify.

This policy is not a substitute for a separate contributor agreement if the project later adopts one.
